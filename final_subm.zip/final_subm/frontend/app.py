# Streamlit Main UI
import streamlit as st
from components.chat_ui import chat_ui

st.set_page_config(page_title="University AI Assistant", layout="wide")

st.title("🎓 University AI Assistant")
chat_ui()
