# Enhanced Chat UI Component with Conversation History & Context Settings

from datetime import datetime

import requests
import streamlit as st

API_URL = "http://127.0.0.1:8000"


def get_source_badge(source: str, is_from_docs: bool) -> str:
    """Get a visual badge for the response source."""
    badges = {
        "cache": "From Cache",
        "memory": "From Memory",
        "rag": "From RAG Docs",
        "general": "From General Agent",
        "multi_agent": "From Multi-Agent",
        "fees": "From Fees Agent",
        "calendar": "From Calendar Agent",
        "timetable": "From Timetable Agent",
        "course": "From Course Agent",
        "faculty": "From Faculty Agent",
        "map": "From Map Agent",
        "model": "From AI",
        "guardrail": "Blocked",
    }
    return badges.get(source, "System")


def init_session_state():
    """Initialize session state variables."""
    if "user_id" not in st.session_state:
        st.session_state.user_id = "student_001"
    if "conversation_id" not in st.session_state:
        st.session_state.conversation_id = f"conv_{int(datetime.now().timestamp())}"
    if "messages" not in st.session_state:
        st.session_state.messages = []
    if "context_settings" not in st.session_state:
        st.session_state.context_settings = {
            "context_length": 5,
            "rag_enabled": True,
            "memory_enabled": True,
            "use_cache": True,
        }
    if "show_settings" not in st.session_state:
        st.session_state.show_settings = False


def load_conversation_history(user_id: str):
    """Load conversation history from backend."""
    try:
        response = requests.get(f"{API_URL}/chat/user/{user_id}/conversation-history")
        if response.status_code == 200:
            return response.json().get("conversation_history", [])
    except Exception as e:
        st.warning(f"Could not load conversation history: {e}")
    return []


def load_context_settings(user_id: str):
    """Load context settings from backend."""
    try:
        response = requests.get(f"{API_URL}/chat/user/{user_id}/context-settings")
        if response.status_code == 200:
            return response.json()
    except Exception as e:
        st.warning(f"Could not load context settings: {e}")
    return None


def save_context_settings(user_id: str, settings: dict):
    """Save context settings to backend."""
    try:
        response = requests.post(
            f"{API_URL}/chat/user/{user_id}/context-settings",
            json=settings,
        )
        return response.status_code == 200
    except Exception as e:
        st.error(f"Could not save settings: {e}")
    return False


def clear_conversation(user_id: str):
    """Clear conversation history."""
    try:
        response = requests.post(f"{API_URL}/chat/user/{user_id}/clear-conversation")
        return response.status_code == 200
    except Exception as e:
        st.error(f"Could not clear conversation: {e}")
    return False


def chat_ui():
    """Enhanced chat UI with conversation history and context settings."""
    st.subheader("Enhanced Chat Assistant")

    init_session_state()

    with st.sidebar:
        st.header("Settings")

        new_user_id = st.text_input(
            "User ID",
            value=st.session_state.user_id,
            help="This maintains persistent memory across conversations",
        )

        if new_user_id != st.session_state.user_id:
            st.session_state.user_id = new_user_id
            st.session_state.conversation_id = f"conv_{int(datetime.now().timestamp())}"
            st.session_state.messages = []
            st.rerun()

        st.divider()

    st.markdown(f"### Chat with {st.session_state.user_id}")

    chat_container = st.container(border=True, height=400)

    with chat_container:
        if st.session_state.messages:
            for msg in st.session_state.messages:
                if msg["role"] == "user":
                    with st.chat_message("user", avatar="👤"):
                        st.markdown(msg["content"])
                        st.caption(f"*{msg.get('timestamp', 'unknown time')}*")
                else:
                    with st.chat_message("assistant", avatar="🤖"):
                        st.markdown(msg["content"])

                        if "source" in msg:
                            source_badge = get_source_badge(
                                msg.get("source", "model"),
                                msg.get("is_from_docs", False),
                            )
                            st.caption(f"Source: {source_badge}")
                        if msg.get("agents_used"):
                            st.caption(
                                "Agents: " + ", ".join(msg.get("agents_used", []))
                            )

                        st.caption(f"*{msg.get('timestamp', 'unknown time')}*")
        else:
            st.info(
                "No messages yet. Ask here about fees, timetable, calendar, courses, policies, or your stored student profile."
            )

    st.divider()

    st.markdown("**Your Message:**")
    col1, col2 = st.columns([5, 1])

    with col1:
        user_input = st.text_input(
            "message",
            placeholder="Ask me anything about the university...",
            label_visibility="collapsed",
        )

    with col2:
        send_button = st.button("Send", use_container_width=True, type="primary")

    if send_button and user_input.strip():
        user_msg = {
            "role": "user",
            "content": user_input,
            "timestamp": datetime.now().strftime("%H:%M:%S"),
        }
        st.session_state.messages.append(user_msg)

        with st.spinner("Thinking..."):
            try:
                payload = {
                    "user_id": st.session_state.user_id,
                    "conversation_id": st.session_state.conversation_id,
                    "message": user_input,
                    "end_conversation": False,
                }

                response = requests.post(f"{API_URL}/chat/", json=payload)
                response.raise_for_status()
                result = response.json()

                assistant_msg = {
                    "role": "assistant",
                    "content": result.get("response", "No response received"),
                    "timestamp": datetime.now().strftime("%H:%M:%S"),
                    "source": result.get("source", "model"),
                    "is_from_docs": result.get("is_from_docs", False),
                    "agents_used": result.get("agents_used", []),
                }
                st.session_state.messages.append(assistant_msg)

                st.success("Response received.")
                st.rerun()

            except requests.exceptions.ConnectionError:
                st.error(
                    "Cannot connect to backend.\n\n"
                    "Make sure the backend is running:\n"
                    "`python -m uvicorn backend.main:app --reload`"
                )
            except requests.exceptions.Timeout:
                st.error("Backend request timed out. Please try again.")
            except Exception as e:
                st.error(f"Error: {str(e)}")

    st.divider()

    col1, col2 = st.columns(2)
    with col1:
        st.caption(
            f"ID: {st.session_state.conversation_id[:15]}... | User: {st.session_state.user_id}"
        )
    with col2:
        st.caption(f"Messages: {len(st.session_state.messages)}")
