# Text Splitter Utility
from langchain_text_splitters import RecursiveCharacterTextSplitter

def split_documents(documents):
    """
    Split large documents into chunks
    """
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=50
    )

    return splitter.split_documents(documents)