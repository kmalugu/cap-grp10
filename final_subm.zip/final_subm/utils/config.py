import os

from dotenv import load_dotenv

load_dotenv()

GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
MODEL_NAME = GEMINI_MODEL
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "")
EMBEDDING_MODEL = os.getenv(
    "EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2"
)
LLM_TEMPERATURE = float(os.getenv("LLM_TEMPERATURE", "0.2"))
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
REDIS_ENABLED = os.getenv("REDIS_ENABLED", "true").lower() == "true"
CACHE_TTL_SECONDS = int(os.getenv("CACHE_TTL_SECONDS", "3600"))

# Paths - Use absolute paths
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAG_DOCS_PATH = os.path.join(PROJECT_ROOT, "data", "rag_docs")
FAISS_PATH = os.path.join(PROJECT_ROOT, "models", "faiss_index")
CHROMA_PATH = os.path.join(PROJECT_ROOT, "models", "chroma_db")
VECTOR_MEMORY_COLLECTION = "student_long_term_memory_hf"
