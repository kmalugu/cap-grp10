#!/usr/bin/env python3
"""
Comprehensive Memory System Testing
Tests storing and retrieving student memories
"""

import requests
import json
from time import sleep

API_URL = "http://127.0.0.1:8000"
TEST_STUDENT_ID = "memory_test_student"
TEST_CONV_ID = f"test_conv_{int(__import__('time').time())}"

print("\n" + "="*70)
print("MEMORY SYSTEM COMPREHENSIVE TEST")
print("="*70)

# Test 1: Send messages that should trigger memory processing
print("\n1. Sending test messages (should extract info)...")
print("-" * 70)

test_messages = [
    {
        "message": "Hi, I'm Alice studying MSc in Computer Science",
        "expected_extraction": "name, program, department"
    },
    {
        "message": "I'm in my second year and interested in AI and Machine Learning",
        "expected_extraction": "year, courses_interested"
    },
    {
        "message": "I have issues with understanding algorithms",
        "expected_extraction": "ongoing_issues"
    }
]

for i, msg_data in enumerate(test_messages, 1):
    try:
        response = requests.post(
            f"{API_URL}/chat/",
            json={
                "user_id": TEST_STUDENT_ID,
                "conversation_id": TEST_CONV_ID,
                "message": msg_data["message"],
                "end_conversation": False
            },
            timeout=60
        )
        
        if response.status_code == 200:
            data = response.json()
            print(f"\n✓ Message {i}: '{msg_data['message'][:40]}...'")
            print(f"  Source: {data.get('source', 'unknown')}")
            print(f"  Memory processed: {data.get('conversation_processed', False)}")
        else:
            print(f"\n✗ Message {i} failed: {response.status_code}")
            print(f"  Error: {response.text[:200]}")
    except Exception as e:
        print(f"\n✗ Error sending message {i}: {e}")
        break

# Wait a moment for processing
sleep(2)

# Test 2: Check if memory was stored
print("\n\n2. Checking stored memory...")
print("-" * 70)

try:
    response = requests.get(
        f"{API_URL}/chat/debug/memory/{TEST_STUDENT_ID}",
        timeout=10
    )
    
    if response.status_code == 200:
        data = response.json()
        entity = data.get("entity_memory")
        
        print(f"\n✓ Memory retrieved for {TEST_STUDENT_ID}")
        
        if entity:
            print(f"  Name: {entity.get('name')}")
            print(f"  Program: {entity.get('program')}")
            print(f"  Year: {entity.get('year')}")
            print(f"  Department: {entity.get('department')}")
            print(f"  Ongoing Issues: {entity.get('ongoing_issues')}")
            print(f"  Interested Courses: {entity.get('courses_interested')}")
        else:
            print("  ⚠️  No entity memory found")
        
        summaries = data.get("summaries", [])
        if summaries:
            print(f"\n  Conversation Summaries ({len(summaries)}):")
            for summary in summaries:
                print(f"    - {summary.get('summary')[:80]}...")
        
        interests = data.get("academic_interests", [])
        if interests:
            print(f"\n  Academic Interests ({len(interests)}):")
            for interest in interests:
                print(f"    - {interest.get('content')}")
        
        doubts = data.get("previous_doubts", [])
        if doubts:
            print(f"\n  Previous Doubts ({len(doubts)}):")
            for doubt in doubts:
                print(f"    - {doubt.get('content')}")
    else:
        print(f"✗ Failed to retrieve memory: {response.status_code}")
        
except Exception as e:
    print(f"✗ Error retrieving memory: {e}")

# Test 3: Check raw memory file
print("\n\n3. Checking raw memory file...")
print("-" * 70)

try:
    response = requests.get(
        f"{API_URL}/chat/debug/memory/{TEST_STUDENT_ID}/raw-file",
        timeout=10
    )
    
    if response.status_code == 200:
        data = response.json()
        if data.get("status") == "found":
            print(f"\n✓ Raw memory file exists")
            print(f"  Content: {json.dumps(data.get('memory'), indent=2)[:500]}...")
        else:
            print(f"\n⚠️  Memory file not found in raw storage")
    else:
        print(f"✗ Failed to retrieve raw memory: {response.status_code}")
        
except Exception as e:
    print(f"✗ Error retrieving raw memory: {e}")

# Test 4: Test memory retrieval in subsequent chat
print("\n\n4. Testing memory retrieval in new message...")
print("-" * 70)

try:
    response = requests.post(
        f"{API_URL}/chat/",
        json={
            "user_id": TEST_STUDENT_ID,
            "conversation_id": TEST_CONV_ID,
            "message": "Based on what I've told you, what electives should I take?",
            "end_conversation": False
        },
        timeout=60
    )
    
    if response.status_code == 200:
        data = response.json()
        print(f"\n✓ Question asked: 'Based on what I've told you...'")
        print(f"  Response includes student context: {bool(data.get('student_context'))}")
        if data.get('student_context'):
            print(f"  Student info in response: {str(data['student_context'])[:200]}...")
        print(f"  Response: {data.get('response', '')[:200]}...")
    else:
        print(f"✗ Failed: {response.status_code}")
        
except Exception as e:
    print(f"✗ Error: {e}")

print("\n" + "="*70)
print("TEST COMPLETE")
print("="*70)
print("\nTo manually test memory update:")
print(f"curl -X POST http://127.0.0.1:8000/chat/debug/memory/{TEST_STUDENT_ID}/update")
print('  -H "Content-Type: application/json"')
print('  -d "{{name: Alice, program: MSc}}"')
print("\nTo verify stored memory:")
print(f"curl http://127.0.0.1:8000/chat/debug/memory/{TEST_STUDENT_ID}")
print("\n")
