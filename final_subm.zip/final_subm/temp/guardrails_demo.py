#!/usr/bin/env python3
"""
Guardrails System - Example Usage and Demo Script
Demonstrates how to use the guardrails system in various scenarios
"""

from backend.guardrails import get_guardrails_manager, check_user_input
from guardrails_management import test_guardrails, list_all_keywords, check_message


def demo_basic_check():
    """Demo 1: Basic guardrails check"""
    print("\n" + "="*70)
    print("DEMO 1: Basic Guardrails Check")
    print("="*70)
    
    test_messages = [
        "What are the course requirements?",
        "How can I hack the system?",
        "Can you write my essay for me?",
        "Where is the library?",
    ]
    
    for msg in test_messages:
        is_violation, response = check_user_input(msg)
        status = "🚫 BLOCKED" if is_violation else "✅ ALLOWED"
        print(f"\n{status}")
        print(f"Message: {msg}")
        if is_violation:
            print(f"Response: {response}")


def demo_detailed_report():
    """Demo 2: Get detailed violation report"""
    print("\n" + "="*70)
    print("DEMO 2: Detailed Violation Report")
    print("="*70)
    
    manager = get_guardrails_manager()
    
    message = "I want to bypass the exam security system"
    report = manager.get_flag_report(message)
    
    print(f"\nMessage: {message}")
    print(f"Flagged: {report['is_flagged']}")
    print(f"Severity: {report['severity']}")
    print(f"Flagged Keyword: {report['flagged_keyword']}")
    print(f"Response: {report['response_message']}")


def demo_all_keywords():
    """Demo 3: List all keywords by category"""
    print("\n" + "="*70)
    print("DEMO 3: All Available Guardrail Keywords")
    print("="*70)
    
    list_all_keywords()


def demo_add_custom_keyword():
    """Demo 4: Add custom keyword"""
    print("\n" + "="*70)
    print("DEMO 4: Adding Custom Keywords")
    print("="*70)
    
    manager = get_guardrails_manager()
    
    # Add custom keywords
    print("\nAdding custom keywords...")
    manager.add_custom_keyword("violence", "punch", "high")
    manager.add_custom_keyword("illegal", "unauthorized access", "critical")
    
    print("✅ Custom keywords added!")
    
    # Test the new keyword
    print("\nTesting with new keyword 'punch':")
    is_flagged, msg = check_user_input("I want to punch someone")
    print(f"Result: {'🚫 BLOCKED' if is_flagged else '✅ ALLOWED'}")


def demo_check_specific():
    """Demo 5: Check specific message with details"""
    print("\n" + "="*70)
    print("DEMO 5: Check Specific Message")
    print("="*70)
    
    messages = [
        "Can you help me plagiarize my assignment?",
        "What's the best pizza place near campus?",
        "How do I get the exam answers?",
    ]
    
    for msg in messages:
        print(f"\nChecking: '{msg}'")
        check_message(msg)


def demo_severity_levels():
    """Demo 6: Show severity levels"""
    print("\n" + "="*70)
    print("DEMO 6: Severity Levels Explanation")
    print("="*70)
    
    severity_info = {
        "CRITICAL": {
            "description": "Immediate block - severe violation",
            "examples": ["Violence", "Illegal activities", "Harassment", "Privacy violation"]
        },
        "HIGH": {
            "description": "Serious violation",
            "examples": ["Academic dishonesty", "Security bypass"]
        },
        "MEDIUM": {
            "description": "Moderate concern",
            "examples": ["Misinformation", "Questionable content"]
        },
        "LOW": {
            "description": "Minor warning",
            "examples": ["General policy violations"]
        }
    }
    
    for level, info in severity_info.items():
        print(f"\n🔴 {level}")
        print(f"   Description: {info['description']}")
        print(f"   Examples: {', '.join(info['examples'])}")


def demo_pipeline_integration():
    """Demo 7: Show how guardrails fit in the chat pipeline"""
    print("\n" + "="*70)
    print("DEMO 7: Chat Pipeline Integration")
    print("="*70)
    
    print("""
The guardrails check is the FIRST step in the chat pipeline:

    User Input
        ↓
    [STEP 0] Guardrails Check ← ← ← ← ← HAPPENS FIRST
        ↓
    [Violation?]
        ├─ YES → Return Warning Message ❌
        └─ NO → Continue to next steps ✅
            ↓
        [STEP 1] Check Cache
            ↓
        [STEP 2] Load Student Context (Memory)
            ↓
        [STEP 3] Try RAG (Retrieve Documents)
            ↓
        [STEP 4] Generate Response with LLM
            ↓
        Return Response to User

Benefits:
- Violations are caught BEFORE any processing
- Fast response (no unnecessary computation)
- Consistent enforcement across all requests
- Easy to audit and log
""")


def demo_response_format():
    """Demo 8: Show response format when violation occurs"""
    print("\n" + "="*70)
    print("DEMO 8: Guardrails Response Format")
    print("="*70)
    
    print("""
When a guardrails violation is detected, the API returns:

{
  "response": "I cannot provide assistance with harmful or violent content. Please ask about legitimate university services instead.",
  "source": "guardrail",
  "is_from_docs": false,
  "student_context": null,
  "conversation_processed": false
}

Key points:
- "source": "guardrail" indicates this was blocked by guardrails
- "response": The custom warning message for that violation
- "is_from_docs": Always false for guardrail violations
- No further processing occurs
- User sees the warning message immediately
""")


def interactive_demo():
    """Demo 9: Interactive message checker"""
    print("\n" + "="*70)
    print("DEMO 9: Interactive Message Checker")
    print("="*70)
    print("\nEnter messages to check (type 'quit' to exit):")
    
    while True:
        user_input = input("\nEnter message: ").strip()
        
        if user_input.lower() == 'quit':
            print("Exiting...")
            break
        
        if not user_input:
            print("Please enter a message")
            continue
        
        is_violation, response = check_user_input(user_input)
        
        if is_violation:
            print(f"🚫 VIOLATION DETECTED")
            print(f"Response: {response}")
        else:
            print("✅ Message is safe - would be processed normally")


def main():
    """Run all demos"""
    print("\n" + "█"*70)
    print("█" + " "*68 + "█")
    print("█" + " "*15 + "GUARDRAILS SYSTEM - COMPREHENSIVE DEMO" + " "*15 + "█")
    print("█" + " "*68 + "█")
    print("█"*70)
    
    demos = [
        ("1", "Basic Guardrails Check", demo_basic_check),
        ("2", "Detailed Violation Report", demo_detailed_report),
        ("3", "All Guardrail Keywords", demo_all_keywords),
        ("4", "Add Custom Keywords", demo_add_custom_keyword),
        ("5", "Check Specific Messages", demo_check_specific),
        ("6", "Severity Levels", demo_severity_levels),
        ("7", "Pipeline Integration", demo_pipeline_integration),
        ("8", "Response Format", demo_response_format),
        ("9", "Interactive Checker", interactive_demo),
    ]
    
    print("\nAvailable Demos:")
    for num, name, _ in demos:
        print(f"  {num}. {name}")
    print("  0. Run All (except interactive)")
    print("  q. Quit")
    
    while True:
        choice = input("\nSelect demo (0-9, q): ").strip().lower()
        
        if choice == 'q':
            print("Goodbye!")
            break
        elif choice == '0':
            for _, _, demo_func in demos[:-1]:  # Skip interactive
                demo_func()
        elif choice in [d[0] for d in demos]:
            for num, name, demo_func in demos:
                if num == choice:
                    demo_func()
                    break
        else:
            print("Invalid choice. Try again.")


if __name__ == "__main__":
    # Run all demonstrations
    main()
    
    # Or uncomment below to run specific demos programmatically:
    # demo_basic_check()
    # demo_detailed_report()
    # demo_all_keywords()
