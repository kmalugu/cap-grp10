@echo off
echo Starting University AI Assistant...
echo.
echo Optional: start Redis first with `docker compose up -d redis`
echo.
echo 1. Starting Backend on http://localhost:8000
start cmd /k "cd /d %~dp0 && python -m uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000"
timeout /t 3 /nobreak

echo.
echo 2. Starting Frontend on http://localhost:8501
timeout /t 2 /nobreak
start cmd /k "cd /d %~dp0 && streamlit run frontend/app.py"

echo.
echo Both services should now be running!
echo - Backend: http://localhost:8000
echo - Frontend: http://localhost:8501
echo.
pause
