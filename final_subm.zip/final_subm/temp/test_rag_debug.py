#!/usr/bin/env python3
"""Test RAG pipeline"""

from backend.services.retriever import retrieve_documents
import os

# Test RAG retrieval
test_queries = [
    'library rules',
    'how many books can I borrow',
    'library timings',
    'hostel guidelines',
    'placement',
]

print("=" * 60)
print("RAG PIPELINE TEST")
print("=" * 60)

# Check if FAISS index exists
faiss_path = "models/faiss_index"
if os.path.exists(faiss_path):
    print(f"✅ FAISS index path exists: {faiss_path}")
else:
    print(f"❌ FAISS index path NOT found: {faiss_path}")

print("\nTesting queries:")
print("-" * 60)

for query in test_queries:
    docs = retrieve_documents(query, k=3)
    print(f"\nQuery: '{query}'")
    print(f"  Found: {len(docs)} documents")
    if docs:
        for i, doc in enumerate(docs, 1):
            content_preview = doc.page_content[:100].replace('\n', ' ')
            print(f"    [{i}] {content_preview}...")
    else:
        print("    (No documents found)")

print("\n" + "=" * 60)
