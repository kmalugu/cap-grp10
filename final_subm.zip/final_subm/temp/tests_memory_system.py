#!/usr/bin/env python3
"""
Unit Tests for Memory System

Run with: pytest tests_memory_system.py -v

Tests all three memory types:
- Entity Memory
- Summary Memory  
- Vector Memory
"""

import pytest
import json
import os
from datetime import datetime
from backend.services.memory import (
    MemoryManager,
    StudentEntityMemory,
    SummaryMemory,
)


class TestEntityMemory:
    """Test Entity Memory functionality"""

    @pytest.fixture
    def memory_manager(self):
        """Create a memory manager for testing"""
        return MemoryManager()

    @pytest.fixture
    def student_id(self):
        return "test_student_001"

    def test_create_entity_memory(self, memory_manager, student_id):
        """Test creating new entity memory"""
        entity = memory_manager.create_entity_memory(student_id, "John Doe")

        assert entity.student_id == student_id
        assert entity.name == "John Doe"
        assert entity.ongoing_issues == []
        assert entity.courses_interested == []
        assert entity.created_at is not None

    def test_get_entity_memory(self, memory_manager, student_id):
        """Test retrieving entity memory"""
        # Create first
        memory_manager.create_entity_memory(student_id, "Jane Smith")

        # Retrieve
        entity = memory_manager.get_entity_memory(student_id)

        assert entity is not None
        assert entity.name == "Jane Smith"

    def test_update_entity_memory(self, memory_manager, student_id):
        """Test updating entity memory fields"""
        memory_manager.create_entity_memory(student_id, "Test Student")

        # Update multiple fields
        updated = memory_manager.update_entity_memory(
            student_id,
            program="MSc",
            year="1st",
            department="Computer Science",
            ongoing_issues=["course_selection", "thesis"],
            courses_interested=["AI", "ML"],
        )

        assert updated.program == "MSc"
        assert updated.year == "1st"
        assert updated.department == "Computer Science"
        assert len(updated.ongoing_issues) == 2
        assert len(updated.courses_interested) == 2
        assert updated.updated_at is not None

    def test_entity_memory_persistence(self, memory_manager, student_id):
        """Test that entity memory persists to disk"""
        memory_manager.create_entity_memory(student_id, "Persistent Student")

        # Load from disk
        memory = memory_manager.load_memory()

        assert student_id in memory
        assert memory[student_id]["entity"]["name"] == "Persistent Student"

    def test_entity_memory_to_dict(self, memory_manager, student_id):
        """Test entity memory serialization"""
        entity = memory_manager.create_entity_memory(student_id, "Test User")
        entity_dict = entity.to_dict()

        assert isinstance(entity_dict, dict)
        assert "student_id" in entity_dict
        assert "name" in entity_dict
        assert "ongoing_issues" in entity_dict


class TestSummaryMemory:
    """Test Summary Memory functionality"""

    @pytest.fixture
    def memory_manager(self):
        return MemoryManager()

    @pytest.fixture
    def student_id(self):
        return "test_student_002"

    def test_save_conversation_summary(self, memory_manager, student_id):
        """Test saving conversation summary"""
        conv_id = "conv_001"
        summary = "Discussed course selection and career path"
        topics = ["courses", "career"]

        saved = memory_manager.save_conversation_summary(
            student_id, conv_id, summary, topics, 8
        )

        assert saved.student_id == student_id
        assert saved.conversation_id == conv_id
        assert saved.summary == summary
        assert saved.key_topics == topics
        assert saved.conversation_length == 8

    def test_get_conversation_summary(self, memory_manager, student_id):
        """Test retrieving conversation summary"""
        conv_id = "conv_002"
        memory_manager.save_conversation_summary(
            student_id, conv_id, "Test summary", ["test"], 5
        )

        retrieved = memory_manager.get_conversation_summary(student_id, conv_id)

        assert retrieved is not None
        assert retrieved.conversation_id == conv_id
        assert retrieved.summary == "Test summary"

    def test_get_all_summaries(self, memory_manager, student_id):
        """Test retrieving all summaries for a student"""
        # Create multiple summaries
        memory_manager.save_conversation_summary(
            student_id, "conv_001", "Summary 1", ["topic1"], 5
        )
        memory_manager.save_conversation_summary(
            student_id, "conv_002", "Summary 2", ["topic2"], 6
        )

        summaries = memory_manager.get_all_summaries(student_id)

        assert len(summaries) == 2
        assert any(s.summary == "Summary 1" for s in summaries)
        assert any(s.summary == "Summary 2" for s in summaries)

    def test_summary_memory_persistence(self, memory_manager, student_id):
        """Test that summaries persist to disk"""
        memory_manager.save_conversation_summary(
            student_id, "conv_001", "Persistent summary", ["test"], 7
        )

        # Load from disk
        memory = memory_manager.load_memory()

        assert student_id in memory
        assert "summaries" in memory[student_id]
        assert "conv_001" in memory[student_id]["summaries"]


class TestVectorMemory:
    """Test Vector Memory functionality"""

    @pytest.fixture
    def memory_manager(self):
        return MemoryManager()

    @pytest.fixture
    def student_id(self):
        return "test_student_003"

    def test_add_doubt_to_vector_memory(self, memory_manager, student_id):
        """Test adding a doubt to vector memory"""
        doubt_content = "How to approach machine learning projects?"

        doc_id = memory_manager.add_to_vector_memory(
            student_id, doubt_content, "doubt", {"topic": ["ml", "projects"]}
        )

        assert doc_id is not None
        assert student_id in doc_id
        assert "doubt" in doc_id

    def test_add_interest_to_vector_memory(self, memory_manager, student_id):
        """Test adding an interest to vector memory"""
        interest_content = "Natural Language Processing Applications"

        doc_id = memory_manager.add_to_vector_memory(
            student_id, interest_content, "interest", {"topic": ["nlp", "ai"]}
        )

        assert doc_id is not None

    def test_add_elective_to_vector_memory(self, memory_manager, student_id):
        """Test adding an elective preference to vector memory"""
        elective_content = "Advanced Deep Learning"

        doc_id = memory_manager.add_to_vector_memory(
            student_id, elective_content, "elective", {"topic": ["dl", "ai"]}
        )

        assert doc_id is not None

    def test_search_vector_memory(self, memory_manager, student_id):
        """Test searching vector memory"""
        # Add some memories
        memory_manager.add_to_vector_memory(
            student_id, "Neural networks and deep learning", "interest"
        )
        memory_manager.add_to_vector_memory(
            student_id, "Machine learning optimization techniques", "doubt"
        )

        # Search for similar
        results = memory_manager.search_vector_memory(
            student_id, "deep neural networks", n_results=2
        )

        # Should find relevant results
        assert len(results) > 0
        assert "content" in results[0]
        assert "metadata" in results[0]

    def test_get_vector_memory_by_type(self, memory_manager, student_id):
        """Test retrieving vector memory by type"""
        # Add doubts
        memory_manager.add_to_vector_memory(
            student_id, "Doubt 1", "doubt"
        )
        memory_manager.add_to_vector_memory(
            student_id, "Doubt 2", "doubt"
        )

        # Add interest
        memory_manager.add_to_vector_memory(
            student_id, "Interest 1", "interest"
        )

        # Retrieve by type
        doubts = memory_manager.get_vector_memory_by_type(student_id, "doubt")
        interests = memory_manager.get_vector_memory_by_type(student_id, "interest")

        assert len(doubts) >= 2
        assert len(interests) >= 1

    def test_vector_memory_metadata(self, memory_manager, student_id):
        """Test that metadata is stored with vector memories"""
        metadata = {
            "topic": ["ai", "ml"],
            "semester": "spring_2024",
        }

        memory_manager.add_to_vector_memory(
            student_id,
            "Test content",
            "interest",
            metadata=metadata,
        )

        results = memory_manager.get_vector_memory_by_type(student_id, "interest")

        if results:
            assert "metadata" in results[0]
            # Verify metadata was stored
            stored_metadata = results[0]["metadata"]
            assert "student_id" in stored_metadata
            assert "type" in stored_metadata


class TestCompleteContext:
    """Test complete context retrieval"""

    @pytest.fixture
    def memory_manager(self):
        return MemoryManager()

    @pytest.fixture
    def student_id(self):
        return "test_student_004"

    def test_get_complete_context(self, memory_manager, student_id):
        """Test getting complete student context"""
        # Set up entity
        memory_manager.create_entity_memory(student_id, "Complete Test")

        # Add summary
        memory_manager.save_conversation_summary(
            student_id, "conv_001", "Test summary", ["test"], 5
        )

        # Add vector memories
        memory_manager.add_to_vector_memory(
            student_id, "Test interest", "interest"
        )
        memory_manager.add_to_vector_memory(
            student_id, "Test doubt", "doubt"
        )

        # Get complete context
        context = memory_manager.get_complete_context(student_id)

        assert context["entity"] is not None
        assert len(context["summaries"]) > 0
        assert isinstance(context["academic_interests"], list)
        assert isinstance(context["previous_doubts"], list)

    def test_complete_context_empty_student(self, memory_manager):
        """Test getting context for student with no history"""
        context = memory_manager.get_complete_context("nonexistent_student")

        assert context["entity"] is None
        assert context["summaries"] == []
        assert context["academic_interests"] == []
        assert context["previous_doubts"] == []


class TestDataIntegrity:
    """Test data integrity and error handling"""

    @pytest.fixture
    def memory_manager(self):
        return MemoryManager()

    def test_memory_file_format(self, memory_manager):
        """Test that memory file is valid JSON"""
        student_id = "test_integrity_001"
        memory_manager.create_entity_memory(student_id, "Integrity Test")

        # Load and verify JSON validity
        with open("data/memory/student_memory.json", "r") as f:
            data = json.load(f)

        assert isinstance(data, dict)
        assert student_id in data

    def test_entity_dataclass_serialization(self):
        """Test entity memory serialization"""
        entity = StudentEntityMemory(
            student_id="test",
            name="Test User",
            program="MSc",
            year="1st",
        )

        entity_dict = entity.to_dict()

        # Verify all fields are serializable
        json_str = json.dumps(entity_dict)
        restored = json.loads(json_str)

        assert restored["student_id"] == "test"
        assert restored["name"] == "Test User"

    def test_summary_dataclass_serialization(self):
        """Test summary memory serialization"""
        summary = SummaryMemory(
            student_id="test",
            conversation_id="conv_001",
            summary="Test summary",
            key_topics=["topic1", "topic2"],
            timestamp=datetime.now().isoformat(),
            conversation_length=5,
        )

        summary_dict = summary.to_dict()
        json_str = json.dumps(summary_dict)
        restored = json.loads(json_str)

        assert restored["conversation_id"] == "conv_001"
        assert len(restored["key_topics"]) == 2


@pytest.mark.integration
class TestMemoryGraphIntegration:
    """Integration tests with the memory graph workflow"""

    def test_memory_graph_import(self):
        """Test that memory graph can be imported"""
        try:
            from backend.services.memory_graph import (
                process_conversation_for_memory,
                memory_graph,
            )

            assert callable(process_conversation_for_memory)
            assert memory_graph is not None
        except ImportError as e:
            pytest.fail(f"Failed to import memory_graph: {e}")

    def test_conversational_state_creation(self):
        """Test ConversationState object creation"""
        from backend.services.memory_graph import ConversationState

        state = ConversationState(
            student_id="test",
            conversation_id="conv_001",
            messages=[
                {"role": "user", "content": "Hello"},
                {"role": "assistant", "content": "Hi"},
            ],
        )

        assert state.student_id == "test"
        assert state.conversation_id == "conv_001"
        assert len(state.messages) == 2


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
