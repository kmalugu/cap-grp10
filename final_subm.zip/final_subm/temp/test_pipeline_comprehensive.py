#!/usr/bin/env python3
"""
Comprehensive RAG Pipeline Test
Tests: Cache -> Memory -> RAG -> Model flow
"""

import requests
import json
from time import sleep

API_URL = "http://127.0.0.1:8000"

print("\n" + "="*70)
print("COMPREHENSIVE RAG PIPELINE TEST")
print("="*70)

# Test queries that SHOULD be in RAG docs
test_cases = [
    {
        "query": "What are the library borrowing limits?",
        "expected_source": "rag",
        "in_docs": True
    },
    {
        "query": "How many books can I borrow from the library?",
        "expected_source": "rag",
        "in_docs": True
    },
    {
        "query": "What are the library timings?",
        "expected_source": "rag",
        "in_docs": True
    },
    {
        "query": "What is the library card fee?",
        "expected_source": "model",
        "in_docs": False
    },
]

print("\n1. Testing RAG Document Retrieval (Direct)")
print("-" * 70)

for test in test_cases[:3]:  # Test first 3 (should be in docs)
    try:
        response = requests.post(
            f"{API_URL}/chat/debug/test-rag",
            params={"query": test["query"]},
            timeout=30
        )
        if response.status_code == 200:
            data = response.json()
            found = data.get("documents_found", 0)
            print(f"\n✓ Query: '{test['query'][:50]}...'")
            print(f"  Documents Found: {found}")
            if found > 0:
                print(f"  First Doc: {data['documents'][0]['content'][:100]}...")
        else:
            print(f"\n✗ Query failed: {test['query']}")
    except Exception as e:
        print(f"\n✗ Connection error: {e}")
        print("  Make sure backend is running: python -m uvicorn backend.main:app --reload")
        break

print("\n2. Testing Full Chat Pipeline")
print("-" * 70)

# Test with chat endpoint
user_id = "test_user_001"
conv_id = f"test_conv_{int(__import__('time').time())}"

for test in test_cases[:2]:  # Test first 2
    try:
        response = requests.post(
            f"{API_URL}/chat/",
            json={
                "user_id": user_id,
                "conversation_id": conv_id,
                "message": test["query"],
                "end_conversation": False
            },
            timeout=60
        )
        
        if response.status_code == 200:
            data = response.json()
            source = data.get("source", "unknown")
            is_from_docs = data.get("is_from_docs", False)
            
            print(f"\n✓ Query: '{test['query'][:40]}...'")
            print(f"  Source: {source}")
            print(f"  From Docs: {is_from_docs}")
            print(f"  Response: {data['response'][:100]}...")
            
            # Check if matches expectation
            if source == test["expected_source"]:
                print(f"  ✅ CORRECT SOURCE (expected {test['expected_source']})")
            else:
                print(f"  ⚠️  WRONG SOURCE (expected {test['expected_source']}, got {source})")
        else:
            print(f"\n✗ Chat request failed with status {response.status_code}")
            print(f"  Error: {response.text[:200]}")
            
    except Exception as e:
        print(f"\n✗ Error: {e}")
        break

print("\n" + "="*70)
print("TEST COMPLETE")
print("="*70)
print("\nIf RAG returned 'is_from_docs': false for library questions,")
print("check:")
print("1. GOOGLE_API_KEY is set and Gemini 2.5 Flash is reachable")
print("2. FAISS index was created with: python create_index.py")
print("3. Check backend logs for 'RAG found X documents'")
print("\n")
