#!/usr/bin/env python3
"""
Master Evaluation Runner
Runs all evaluation tests with a unified interface
"""

import sys
import time
from evaluation.rag_evaluation import evaluate_rag
from evaluation.advising_quality_simple import evaluate_advising
from evaluation.response_quality import run_response_quality_tests
from evaluation.latency_tests import run_latency_tests


def main():
    """Run all evaluations"""
    
    print("\n" + "█"*70)
    print("█" + " "*68 + "█")
    print("█" + " "*12 + "COMPREHENSIVE EVALUATION SUITE" + " "*26 + "█")
    print("█" + " "*68 + "█")
    print("█"*70)
    
    print("\nStarting evaluation suite...")
    print("This will run 4 evaluation tests (~1 minute total)\n")
    
    start_time = time.time()
    
    try:
        # Test 1: RAG Evaluation
        print("\n[1/4] Running RAG Evaluation...")
        print("-" * 70)
        evaluate_rag()
        
        # Test 2: Advising Quality
        print("\n[2/4] Running Advising Quality Evaluation...")
        print("-" * 70)
        evaluate_advising()
        
        # Test 3: Response Quality
        print("\n[3/4] Running Response Quality Tests...")
        print("-" * 70)
        run_response_quality_tests()
        
        # Test 4: Latency Tests
        print("\n[4/4] Running Latency Tests...")
        print("-" * 70)
        run_latency_tests()
        
        # Summary
        total_time = time.time() - start_time
        
        print("\n" + "█"*70)
        print("█" + " "*68 + "█")
        print("█" + " "*20 + "EVALUATION COMPLETE" + " "*31 + "█")
        print("█" + " "*68 + "█")
        print("█"*70)
        
        print(f"\n✅ All evaluations completed in {total_time:.2f} seconds\n")
        
        print("Summary:")
        print("  ├─ RAG Evaluation: Precision@k, Recall@k, Hit Rate")
        print("  ├─ Advising Quality: 5 dimensions scored")
        print("  ├─ Response Quality: ROUGE-L & BERTScore")
        print("  └─ Latency Tests: Response times measured")
        
        print("\nFor detailed analysis:")
        print("  See EVALUATION_GUIDE.md for interpretation of scores")
        
    except Exception as e:
        print(f"\n❌ Error during evaluation: {e}")
        print("Make sure the backend is running:")
        print("  uvicorn backend.main:app --reload")
        sys.exit(1)


if __name__ == "__main__":
    main()
