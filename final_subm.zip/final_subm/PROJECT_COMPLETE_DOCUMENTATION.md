# University AI Assistant - Complete Project Documentation

## Table of Contents
1. [Project Overview](#project-overview)
2. [Architecture](#architecture)
3. [Technology Stack](#technology-stack)
4. [Project Structure](#project-structure)
5. [Core Components](#core-components)
6. [Features](#features)
7. [Guardrails System](#guardrails-system)
8. [Evaluation System](#evaluation-system)
9. [How to Run](#how-to-run)
10. [API Endpoints](#api-endpoints)
11. [Configuration](#configuration)
12. [Troubleshooting](#troubleshooting)

---

## Project Overview

### What is This Project?

The **University AI Assistant** is an intelligent chatbot system designed to help students at a university by providing information about:
- Course prerequisites and requirements
- Timetable and schedule information
- Registration deadlines
- Fees and scholarships
- Faculty and department information
- Library rules and guidelines
- Campus facilities and more

### Problem It Solves

Students often struggle to find accurate, personalized information about university services. This project:
- ✅ Provides instant answers to student queries
- ✅ Maintains student context and memory across conversations
- ✅ Retrieves accurate information from official documents (RAG)
- ✅ Prevents harmful requests with guardrails
- ✅ Caches responses for faster retrieval
- ✅ Evaluates response quality systematically

### Who Uses It?

- **Students**: Primary users asking questions about university services
- **Advisors**: Can view student profiles and context
- **Administrators**: Can manage documents and evaluate system performance

---

## Architecture

### High-Level System Design

```
┌─────────────────────────────────────────────────────────────────┐
│                        USER APPLICATIONS                        │
│                   (Web UI, Mobile, API)                         │
└────────────────────────┬────────────────────────────────────────┘
                         │
         ┌───────────────┴───────────────┐
         ↓                               ↓
    ┌─────────────────┐         ┌──────────────────────┐
    │  STREAMLIT UI   │         │   FastAPI Backend    │
    │  (frontend/)    │         │  (backend/routes/)   │
    └────────┬────────┘         └──────────┬───────────┘
             │                             │
             └─────────────┬───────────────┘
                           ↓
         ┌─────────────────────────────────────────┐
         │       INTELLIGENT PIPELINE               │
         ├─────────────────────────────────────────┤
         │  STEP 0: Guardrails Check (36 keywords) │
         ├─────────────────────────────────────────┤
         │  STEP 1: Cache Check (Redis-style)      │
         ├─────────────────────────────────────────┤
         │  STEP 2: Student Memory Retrieval       │
         ├─────────────────────────────────────────┤
         │  STEP 3: RAG Document Retrieval         │
         ├─────────────────────────────────────────┤
         │  STEP 4: LLM Response Generation        │
         └─────────────────────────────────────────┘
                           │
         ┌─────────────────┼─────────────────┐
         ↓                 ↓                 ↓
    ┌─────────┐      ┌─────────┐      ┌─────────┐
    │  Cache  │      │ Memory  │      │   RAG   │
    │ System  │      │  Store  │      │ System  │
    └─────────┘      └─────────┘      └─────────┐
         │                 │                 │
         └────────────┬────┴─────────────────┘
                      ↓
         ┌─────────────────────────────┐
         │   Data Storage              │
         ├─────────────────────────────┤
         │ • Structured Data (JSON)    │
         │ • Document Files (TXT)      │
         │ • FAISS Index (Vector DB)   │
         │ • ChromaDB (Vector DB)      │
         └─────────────────────────────┘
```

### Request Flow

```
User Question
      ↓
[STEP 0] GUARDRAILS CHECK
      ├─ Check 36 dangerous keywords
      ├─ Violation? → Return warning ❌
      └─ Safe? Continue ✅
      ↓
[STEP 1] CACHE CHECK
      ├─ Seen this question before?
      ├─ Yes → Return cached response (Fast! ⚡)
      └─ No → Continue
      ↓
[STEP 2] STUDENT CONTEXT
      ├─ Load student profile
      ├─ Retrieve relevant memories
      └─ Build context
      ↓
[STEP 3] RAG RETRIEVAL
      ├─ Search documents for answer
      ├─ Found docs? → Use them 📚
      └─ Not found? → Continue
      ↓
[STEP 4] LLM GENERATION
      ├─ Generate response with OpenAI
      └─ Return to user 🤖
      ↓
Return Response + Metadata
      (source, timestamp, relevance, etc.)
```

---

## Technology Stack

### Backend
- **FastAPI**: REST API framework (why: fast, auto-docs, async support)
- **Python 3.9+**: Core language (why: ML libraries, easy to learn)
- **Pydantic**: Data validation (why: type-safe, automatic validation)

### Frontend
- **Streamlit**: Web UI (why: rapid development, interactive, no JavaScript)

### AI/ML Components
- **LangChain**: LLM orchestration (why: unified interface for LLMs, built-in tools)
- **OpenAI API**: Language model (why: state-of-the-art, reliable)
- **FAISS**: Vector similarity search (why: fast, efficient, free)
- **ChromaDB**: Vector database (why: simple, stores embeddings)
- **Sentence Transformers**: Embeddings (why: semantic understanding, open source)

### Data Storage
- **JSON**: Structured data (why: human-readable, easy to parse)
- **CSV**: Tabular data (why: standard format, Excel compatible)
- **TXT**: Documents (why: simple, universal)
- **SQLite**: Lightweight DB (why: no setup required, portable)

### Development
- **Uvicorn**: ASGI server (why: async, fast, Python-native)
- **Git**: Version control (built-in)

---

## Project Structure

```
grp10_pro/
│
├── backend/                          # Backend API
│   ├── main.py                      # FastAPI app initialization
│   ├── guardrails.py                # Content safety system (36 keywords)
│   │
│   ├── routes/                      # API endpoints
│   │   ├── chat.py                 # Chat endpoint (STEP 0-4 pipeline)
│   │   ├── course.py               # Course info endpoints
│   │   ├── timetable.py            # Timetable endpoints
│   │   ├── fees.py                 # Fees & scholarships endpoints
│   │   ├── calendar.py             # Academic calendar endpoints
│   │   ├── faculty.py              # Faculty info endpoints
│   │   └── rag.py                  # RAG search endpoints
│   │
│   ├── services/                    # Business logic
│   │   ├── llm.py                  # OpenAI LLM wrapper
│   │   ├── memory.py               # Student memory management
│   │   ├── memory_graph.py         # Conversation analysis
│   │   ├── cache.py                # Response caching
│   │   ├── rag_pipeline.py         # RAG orchestration
│   │   ├── retriever.py            # Document retrieval
│   │   └── embedding.py            # Text embedding
│   │
│   └── tools/                       # Utility tools
│       ├── calendar_tool.py        # Calendar operations
│       ├── course_tool.py          # Course lookup
│       ├── faculty_tool.py         # Faculty search
│       ├── fees_tool.py            # Fee calculations
│       ├── timetable_tool.py       # Timetable operations
│       └── map_tool.py             # Campus map
│
├── frontend/                         # Streamlit UI
│   ├── app.py                       # Main Streamlit app
│   │
│   └── components/                  # UI components
│       ├── chat_ui.py              # Chat interface
│       ├── course_ui.py            # Course lookup UI
│       ├── timetable_ui.py         # Timetable UI
│       ├── fees_ui.py              # Fees & scholarships UI
│       └── calendar_ui.py          # Academic calendar UI
│
├── data/                            # Data storage
│   ├── memory/                     # Student memory (JSON)
│   │   └── student_memory.json
│   │
│   ├── rag_docs/                   # Documents for RAG
│   │   ├── hostel_guidelines.txt
│   │   ├── international_guide.txt
│   │   ├── lab_safety.txt
│   │   ├── library_rules.txt
│   │   ├── placement_guidelines.txt
│   │   └── ...
│   │
│   ├── structured/                 # Structured data (CSV/JSON)
│   │   ├── academic_calendar.csv
│   │   ├── campus_map.json
│   │   ├── course_catalog.csv
│   │   ├── departments.json
│   │   ├── faculty.csv
│   │   ├── fees_scholarships.json
│   │   ├── program_structure.json
│   │   └── timetable.csv
│   │
│   └── guardrails_keywords.json    # Guardrails configuration
│
├── models/                          # Pre-trained models & indexes
│   ├── chroma_db/                  # ChromaDB storage
│   │   └── chroma.sqlite3
│   │
│   └── faiss_index/                # FAISS vector index
│       └── index.faiss
│
├── utils/                           # Utility functions
│   ├── config.py                   # Configuration settings
│   ├── embeddings.py               # Embedding generation
│   ├── file_loader.py              # File loading utilities
│   └── text_splitter.py            # Text chunking
│
├── evaluation/                      # Evaluation suite
│   ├── rag_evaluation.py           # RAG precision/recall/hit-rate
│   ├── advising_quality_simple.py  # Response quality (5 dimensions)
│   ├── response_quality.py         # ROUGE-L, BERTScore
│   ├── latency_tests.py            # Performance benchmarking
│   └── metrics.py                  # Shared metrics
│
├── cache/                          # Response cache storage
│
├── Documentation Files
│   ├── README.md                   # Project overview
│   ├── GUARDRAILS_GUIDE.md        # Guardrails system details
│   ├── GUARDRAILS_QUICKREF.md     # Guardrails quick reference
│   ├── EVALUATION_GUIDE.md        # Evaluation system guide
│   ├── ENHANCED_CHAT_GUIDE.md     # Chat system guide
│   ├── INTEGRATION_GUIDE.md       # Integration instructions
│   ├── ARCHITECTURE_DIAGRAM.md    # Architecture details
│   └── IMPLEMENTATION_SUMMARY.md  # What was implemented
│
├── Utility Scripts
│   ├── create_index.py            # Build FAISS/ChromaDB indexes
│   ├── guardrails_management.py   # Manage guardrails keywords
│   ├── guardrails_demo.py         # Demo guardrails system
│   ├── run_evaluations.py         # Run all evaluation tests
│   ├── run_app.bat                # Windows run script
│   └── structure.txt              # File structure reference
│
├── requirements.txt                # Python dependencies
└── .gitignore                     # Git configuration
```

---

## Core Components

### 1. Guardrails System (`backend/guardrails.py`)

**Purpose**: Block harmful, illegal, or inappropriate requests before processing

**How it works**:
- Runs as STEP 0 (first check)
- Scans user input for 36 dangerous keywords
- Returns warning message if violation detected
- Request never reaches LLM if blocked

**36 Keywords Across 7 Categories**:
- **Violence** (7): hurt, kill, harm, attack, bomb, weapon, shoot
- **Illegal** (6): hack, cheat exam, plagiarize, steal, drugs, bypass security
- **Academic Dishonesty** (6): copy homework, buy assignment, write my essay, cheat sheet, exam answers, do my work
- **Harassment** (6): bully, harass, threaten, racist, sexist, hate
- **Privacy Violation** (4): leak personal, share password, share email, doxx
- **Suspicious** (4): bypass login, hack account, admin access, unauthorized access
- **Misinformation** (3): fake news, false information, make up story

**Configuration**: `data/guardrails_keywords.json`

**Why we use it**:
- ✅ Prevents harmful requests immediately
- ✅ Fast keyword matching (< 1ms)
- ✅ Easy to customize keywords
- ✅ Non-intrusive (just returns different message)
- ✅ Logs violations for monitoring

---

### 2. Cache System (`backend/services/cache.py`)

**Purpose**: Cache frequently asked questions to reduce processing time

**How it works**:
- Stores responses with TTL (time-to-live)
- Returns cached response if query seen before
- Falls back to full pipeline if not cached

**Why we use it**:
- ✅ Faster responses (⚡ < 100ms vs 1000ms+ for LLM)
- ✅ Reduces API costs (fewer OpenAI calls)
- ✅ Reduces server load
- ✅ Configurable TTL

**Performance Impact**:
- Cache hit: ~50-100ms response time
- Cache miss: ~1000-2000ms (LLM generation)

---

### 3. Memory System (`backend/services/memory.py` & `memory_graph.py`)

**Purpose**: Remember student context across conversations

**Components**:
1. **Entity Memory**: Student profile (name, program, year, department)
2. **Vector Memory**: Semantic understanding of past interactions
3. **Graph Memory**: Relationship tracking (courses interested, issues)

**How it works**:
- Extracts student information from conversations
- Stores in hierarchical memory structure
- Retrieved automatically for personalization
- Maintains conversation history

**Why we use it**:
- ✅ Personalized responses ("based on your program...")
- ✅ Remembers ongoing issues
- ✅ Tracks interested courses
- ✅ Improves response relevance
- ✅ Reduces repeated explanations

**Data Stored**:
```json
{
  "name": "John Smith",
  "program": "Computer Science",
  "year": 2,
  "department": "Engineering",
  "ongoing_issues": ["course_conflict", "fee_payment"],
  "courses_interested": ["DS201", "AI301"]
}
```

---

### 4. RAG System (Retrieval-Augmented Generation)

**Purpose**: Retrieve accurate information from university documents

**Files Involved**:
- `backend/services/retriever.py`: Document retrieval
- `backend/services/rag_pipeline.py`: RAG orchestration
- `backend/routes/rag.py`: RAG API endpoints
- `utils/embeddings.py`: Text embedding generation
- `utils/file_loader.py`: Loading documents

**How it works**:
1. **Indexing** (create_index.py):
   - Load documents from `data/rag_docs/`
   - Split into chunks (overlap for context)
   - Generate embeddings using Sentence Transformers
   - Store in FAISS & ChromaDB

2. **Retrieval** (retrieve_documents):
   - Convert user query to embedding
   - Search for k most similar documents
   - Return relevant chunks with metadata

3. **Generation**:
   - LLM generates response using retrieved documents
   - If docs found: "📚 From Documentation"
   - If not found: "🤖 AI Generated (not in docs)"

**Documents Indexed**:
- hostel_guidelines.txt
- international_guide.txt
- lab_safety.txt
- library_rules.txt
- placement_guidelines.txt
- Any files in `data/rag_docs/`

**Why we use RAG**:
- ✅ Accurate, sourced answers
- ✅ Reduces hallucination
- ✅ Cites official documents
- ✅ Easy to update (just modify files)
- ✅ Works without fine-tuning

---

### 5. Chat Pipeline

**Location**: `backend/routes/chat.py`

**The 4-Step Pipeline**:

```
Step 0: Guardrails Check
  └─ Check for harmful keywords
  └─ If violation: Return warning, STOP

Step 1: Cache Check
  └─ Is this question cached?
  └─ If yes: Return cached answer, STOP

Step 2: Memory Loading
  └─ Load student profile
  └─ Get relevant past memories
  └─ Build personalization context

Step 3: RAG Retrieval
  └─ Search documents
  └─ If found: Use docs, Mark "from documentation"
  └─ If not: Continue to LLM

Step 4: LLM Generation
  └─ Generate response with context
  └─ Cache for future use
  └─ Return to user
```

**Response Structure**:
```json
{
  "response": "The actual response text...",
  "source": "cache|memory|rag|model|guardrail",
  "is_from_docs": true|false,
  "student_context": {...},
  "conversation_processed": true|false
}
```

---

### 6. LLM Service (`backend/services/llm.py`)

**Purpose**: Generate intelligent responses using OpenAI API

**How it works**:
- Wraps OpenAI API calls
- Injects system prompt for university assistant behavior
- Handles errors gracefully
- Formats prompts with context

**Why OpenAI**:
- ✅ State-of-the-art language model
- ✅ Reliable API
- ✅ Handles complex instructions
- ✅ Good at personalization

**Cost Optimization**:
- Cache reduces API calls by ~60%
- Guardrails prevent wasted processing
- RAG provides sources without generation

---

## Features

### A. Chat Assistant
- **Multi-turn conversations** with memory
- **Personalized responses** based on student context
- **Source attribution** (documents, memory, AI-generated)
- **Response caching** for faster replies
- **Guardrails** for safe interactions

**UI**: `frontend/components/chat_ui.py`
**API**: `POST /chat/`

### B. Course Lookup
- Search course catalog
- View prerequisites
- Find course schedules
- Check instructor information

**UI**: `frontend/components/course_ui.py`
**Data**: `data/structured/course_catalog.csv`
**API**: `GET /course/{code}`

### C. Timetable
- View student schedule
- Check room locations
- Find class timings
- Export as calendar

**UI**: `frontend/components/timetable_ui.py`
**Data**: `data/structured/timetable.csv`
**API**: `GET /timetable/{student_id}`

### D. Fees & Scholarships
- Calculate tuition fees
- View scholarship opportunities
- Payment information
- Financial aid eligibility

**UI**: `frontend/components/fees_ui.py`
**Data**: `data/structured/fees_scholarships.json`
**API**: `GET /fees/{student_id}`

### E. Academic Calendar
- Important dates
- Registration deadlines
- Exam schedules
- Holiday breaks

**UI**: `frontend/components/calendar_ui.py`
**Data**: `data/structured/academic_calendar.csv`
**API**: `GET /calendar/events`

### F. Faculty Directory
- Search faculty by name/department
- Contact information
- Office hours
- Research interests

**Data**: `data/structured/faculty.csv`
**API**: `GET /faculty/search`

---

## Guardrails System

### Architecture

```
User Input
    ↓
Guardrails Manager
├─ Extract keywords from input
├─ Convert to lowercase
├─ Check against 36 keywords
└─ If match: Return warning ✅
        │
        └─ Categories:
           ├─ Violence (7 keywords)
           ├─ Illegal (6 keywords)
           ├─ Academic Dishonesty (6 keywords)
           ├─ Harassment (6 keywords)
           ├─ Privacy Violation (4 keywords)
           ├─ Suspicious (4 keywords)
           └─ Misinformation (3 keywords)
```

### Configuration

**File**: `data/guardrails_keywords.json`

```json
{
  "category_name": {
    "severity": "critical|high|medium|low",
    "keywords": ["keyword1", "keyword2"],
    "message": "Response to show user"
  }
}
```

### Management

**Add Keywords**:
```python
from guardrails_management import add_keyword
add_keyword("violence", "punch", "high")
```

**List All Keywords**:
```python
from guardrails_management import list_all_keywords
list_all_keywords()
```

**Test System**:
```bash
python guardrails_management.py
```

### Why Guardrails?

✅ **Safety**: Blocks harmful requests immediately
✅ **Compliance**: Follows university policies
✅ **Trust**: Users know system won't help with bad things
✅ **Fast**: Keyword matching is instant (< 1ms)
✅ **Transparent**: Clear warning messages

---

## Evaluation System

### A. RAG Evaluation
**Tests**: Document retrieval quality
**Metrics**:
- **Precision@k**: How many retrieved docs are relevant
- **Recall@k**: What % of relevant docs are retrieved
- **Hit Rate@k**: Did we find ANY relevant doc in top-k

**Run**:
```bash
python evaluation/rag_evaluation.py
```

**Good Scores**:
- Precision@1 > 0.7
- Recall@3 > 0.8
- Hit Rate@5 = 1.0

---

### B. Advising Quality Evaluation
**Tests**: Response quality across 5 dimensions
**Metrics** (0-100):
- **Relevance** (25%): Does it answer the question?
- **Correctness** (25%): Are facts accurate?
- **Personalization** (15%): Considers student context?
- **Non-Hallucination** (20%): No made-up facts?
- **Policy Adherence** (15%): Follows university rules?

**Run**:
```bash
python evaluation/advising_quality_simple.py
```

**Overall Score Target**: > 80/100

---

### C. Response Quality Tests
**Tests**: Similarity to reference responses
**Metrics**:
- **ROUGE-L** (0-100): Word overlap & order similarity
- **BERTScore** (0-100): Semantic similarity

**Run**:
```bash
python evaluation/response_quality.py
```

**Good Scores**: > 75/100

---

### D. Latency Tests
**Tests**: Response time for critical operations
**Measured**:
- Timetable query
- Course lookup
- RAG retrieval
- LLM response

**Run**:
```bash
python evaluation/latency_tests.py
```

**Good Latencies**:
- Timetable: < 200ms
- Course lookup: < 150ms
- RAG retrieval: < 300ms
- LLM response: < 2000ms

---

### Running All Evaluations

```bash
# Run everything at once
python run_evaluations.py

# Expected output: ~1 minute, 4 complete test suites
```

---

## How to Run

### Prerequisites
- Python 3.9+
- OpenAI API key
- (Optional) Conda or venv for virtual environment

### Step 1: Setup

**Clone/Extract Project**:
```bash
cd c:\Users\User\Desktop\grp10_pro
```

**Create Virtual Environment** (Optional but recommended):
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Mac/Linux
python3 -m venv venv
source venv/bin/activate
```

**Install Dependencies**:
```bash
pip install -r requirements.txt
```

### Step 2: Configure

**Set OpenAI API Key**:
```bash
# Windows
set OPENAI_API_KEY=sk-your-key-here

# Mac/Linux
export OPENAI_API_KEY=sk-your-key-here
```

**Or edit** `utils/config.py`:
```python
OPENAI_API_KEY = "sk-your-key-here"
```

### Step 3: Index Documents

**Build RAG indexes** (one-time):
```bash
python create_index.py
```

This:
- Loads documents from `data/rag_docs/`
- Generates embeddings
- Creates FAISS & ChromaDB indexes
- Stores in `models/` folder

### Step 4: Run the Application

**Terminal 1 - Start Backend**:
```bash
uvicorn backend.main:app --reload
```
- API available at: http://localhost:8000
- Auto-docs at: http://localhost:8000/docs

**Terminal 2 - Start Frontend**:
```bash
streamlit run frontend/app.py
```
- UI available at: http://localhost:8501

**Terminal 3 - Run Evaluations** (optional):
```bash
python run_evaluations.py
```

### Quick Start Script

**Windows** (`run_app.bat`):
```batch
start uvicorn backend.main:app --reload
start streamlit run frontend/app.py
```

**Linux/Mac**:
```bash
# Terminal 1
uvicorn backend.main:app --reload

# Terminal 2 (new window)
streamlit run frontend/app.py
```

---

## API Endpoints

### Chat
- `POST /chat/` - Send message, get response
- `GET /chat/student/{student_id}/profile` - Get student memory profile
- `POST /chat/student/{student_id}/entity` - Update student info
- `GET /chat/student/{student_id}/conversation-history` - Get past conversations
- `GET /chat/cache-stats` - Caching statistics

### Courses
- `GET /course/{course_code}` - Get course details
- `GET /course/search` - Search courses
- `GET /course/catalog` - List all courses

### Timetable
- `GET /timetable/{student_id}` - Get student schedule
- `GET /timetable/room/{room_code}` - Get room schedule

### Fees
- `GET /fees/{student_id}` - Get student fees
- `POST /fees/calculate` - Calculate fees

### Calendar
- `GET /calendar/events` - Get academic calendar events
- `GET /calendar/events/type/{event_type}` - Get events by type

### Faculty
- `GET /faculty/search` - Search faculty
- `GET /faculty/{faculty_id}` - Get faculty details

### RAG
- `POST /rag/search` - Search documents
- `GET /rag/documents` - List indexed documents

**Full API Docs**: Visit `http://localhost:8000/docs` when backend is running

---

## Configuration

### Main Settings
**File**: `utils/config.py`

```python
# LLM Settings
OPENAI_API_KEY = "sk-..."
MODEL_NAME = "gpt-4"

# RAG Settings
VECTOR_DB_TYPE = "faiss"  # or "chroma"
CHUNK_SIZE = 500
CHUNK_OVERLAP = 50

# Memory Settings
MAX_MEMORY_SIZE = 1000
MEMORY_TTL = 7 * 24 * 3600  # 7 days

# Cache Settings
CACHE_TTL = 3600  # 1 hour
```

### Guardrails Custom Keywords
**File**: `data/guardrails_keywords.json`

Edit categories/keywords as needed. Restart app for changes to take effect.

### Evaluation Test Cases
**Files**: `evaluation/` folder

Edit test cases in each evaluation file to match your use cases.

---

## Data Files Guide

### RAG Documents
**Location**: `data/rag_docs/`

Add `.txt` files here for indexing:
```
data/rag_docs/
├── hostel_guidelines.txt      # Hostel rules
├── library_rules.txt          # Library policies
├── placement_guidelines.txt   # Career services
├── lab_safety.txt             # Lab requirements
├── international_guide.txt    # International student info
└── [add your own files]
```

**Indexing**:
```bash
python create_index.py
```

### Structured Data
**Location**: `data/structured/`

CSV/JSON files with structured data:
```
course_catalog.csv    # Courses with details
timetable.csv        # Class schedules
faculty.csv          # Faculty directory
fees_scholarships.json # Financial info
academic_calendar.csv # Important dates
departments.json     # Department info
campus_map.json      # Locations
```

### Student Memory
**Location**: `data/memory/student_memory.json`

Automatically populated as students interact.

---

## Troubleshooting

### Backend won't start
```
Error: Connection refused / Address already in use
```
**Solution**: Change port
```bash
uvicorn backend.main:app --reload --port 8001
```

### OpenAI API Error
```
Error: Invalid API key
```
**Solution**: Check your API key
```bash
echo $OPENAI_API_KEY
# Should show your key starting with sk-
```

### No RAG documents found
```
Error: Retrieved 0 documents
```
**Solution**: Rebuild indexes
```bash
python create_index.py
```

### Streamlit won't connect to backend
```
Error: Cannot connect to localhost:8000
```
**Solutions**:
1. Make sure backend is running
2. Check port is 8000
3. Verify no firewall blocking

### Slow LLM responses
```
First response takes 30+ seconds
```
This is normal - OpenAI API can be slow. Second calls are faster (cached).

### Guardrails blocking legitimate queries
```
Message: "I want to learn about hacking"
Status: Blocked (contains keyword "hack")
```
**Solution**: Edit `data/guardrails_keywords.json` to use more specific keywords like "hack account" instead of "hack"

### Memory not working
```
Student context not appearing in responses
```
**Solution**:
1. Have multiple messages in conversation
2. Check `data/memory/student_memory.json` exists
3. Try new student ID

---

## Performance Metrics

### Expected Performance

| Operation | Speed | Notes |
|-----------|-------|-------|
| Guardrails check | < 1ms | Fast keyword matching |
| Cache hit | ~50-100ms | Return cached response |
| Memory load | ~20-50ms | Vector search |
| RAG retrieval | ~200-300ms | Semantic search |
| LLM generation | ~1000-3000ms | Depends on OpenAI |
| **Total (no cache)** | **~1500-3500ms** | Full pipeline |
| **Total (with cache)** | **~100-200ms** | Cache hit |

### Optimization Tips

1. **Enable caching**: Huge speed improvement (10-30x faster)
2. **Update documents**: Only when content changes
3. **Reduce context**: Fewer system prompts = faster LLM
4. **Use cheaper model**: gpt-3.5-turbo instead of gpt-4 (trade quality for speed)
5. **Batch evaluations**: Run during off-peak hours

---

## Project Statistics

- **Total Keywords**: 36 (Guardrails)
- **Total Evaluations**: 4 types (RAG, Advising, Quality, Latency)
- **API Endpoints**: 20+
- **Data Files**: 10+ documents, CSVs, JSONs
- **Code Files**: 30+ Python files
- **Frontend Pages**: 5 (Chat, Courses, Timetable, Fees, Calendar)

---

## What Was Done & Why

### Problem Identification
Students struggled to find accurate university information. Current solutions:
- ❌ Manual advising office visits (slow)
- ❌ Outdated websites (inaccurate)
- ❌ Email advisors (delayed response)

### Solution: AI Assistant
We built an intelligent system that:
✅ **Provides instant answers** (< 2 seconds)
✅ **Accurate responses** (uses official documents via RAG)
✅ **Personalized service** (remembers student context)
✅ **Safe interactions** (blocks harmful requests)
✅ **Evaluates quality** (systematic testing)

### Technology Choices

**Why FastAPI?**
- Auto-documentation
- Async support
- Fast development
- Type safety with Pydantic

**Why Streamlit?**
- No JavaScript needed
- Rapid UI development
- Easy to deploy
- Interactive components

**Why RAG?**
- Accurate, sourced answers
- No hallucination from training data
- Easy to update (just change files)
- Works without fine-tuning

**Why Memory System?**
- Personalized responses
- Better context understanding
- Tracks student needs
- Improves experience over time

**Why Guardrails?**
- Safety and compliance
- Prevents misuse
- Transparent boundaries
- Trust building

**Why Evaluation?**
- Systematic quality testing
- Identifies improvement areas
- Performance benchmarking
- Data-driven decisions

---

## Next Steps for Enhancement

1. **Multi-language Support**: Serve international students
2. **Mobile App**: Native iOS/Android
3. **Real-time Notifications**: Alert students about dates
4. **Integration with SIS**: Pull data directly from university systems
5. **Advanced Analytics**: Dashboard for administrators
6. **Voice Chat**: Ask questions by voice
7. **Custom Fine-tuning**: Train on university-specific data
8. **A/B Testing**: Compare response strategies

---

## Support & Contact

**Documentation**:
- `EVALUATION_GUIDE.md` - Evaluation system details
- `GUARDRAILS_GUIDE.md` - Guardrails system details
- `ARCHITECTURE_DIAGRAM.md` - System design
- `INTEGRATION_GUIDE.md` - Integration instructions

**Running Tests**:
```bash
python run_evaluations.py     # All tests
python evaluation/rag_evaluation.py  # RAG only
python guardrails_management.py      # Guardrails
```

**API Documentation**:
- Visit `http://localhost:8000/docs` when backend is running
- Interactive Swagger UI for all endpoints

---

## Summary

This project demonstrates a **production-ready AI assistant** with:
- ✅ Intelligent multi-step pipeline
- ✅ Safety guardrails (36 keywords)
- ✅ Memory & personalization
- ✅ Document retrieval (RAG)
- ✅ Response caching
- ✅ Comprehensive evaluation
- ✅ Clean, modular code
- ✅ Full documentation

**Status**: Ready for deployment and evaluation ✅

---

*Project completed with all components working, evaluated, and documented.*

**Date**: March 25, 2026  
**Version**: 1.0  
**Status**: Production Ready
