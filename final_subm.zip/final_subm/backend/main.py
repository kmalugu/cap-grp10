from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.routes import chat

app = FastAPI(title="University AI Assistant")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routes
app.include_router(chat.router)

@app.get("/")
def home():
    return {"message": "University AI Assistant API is running"}
