from __future__ import annotations

import hashlib
import json
from datetime import datetime, timedelta
from typing import Dict, Optional

from utils.config import CACHE_TTL_SECONDS, REDIS_ENABLED, REDIS_URL

try:
    import redis
except ImportError:  # pragma: no cover - handled by fallback
    redis = None


class CacheEntry:
    """Single in-memory cache entry with TTL support."""

    def __init__(self, content: Dict, ttl_seconds: int = CACHE_TTL_SECONDS):
        self.content = content
        self.created_at = datetime.now()
        self.ttl = timedelta(seconds=ttl_seconds)
        self.access_count = 0
        self.last_accessed = datetime.now()

    def is_expired(self) -> bool:
        return datetime.now() - self.created_at > self.ttl

    def access(self) -> Dict:
        self.access_count += 1
        self.last_accessed = datetime.now()
        return self.content


class InMemoryConversationCache:
    """Fallback cache used when Redis is disabled or unavailable."""

    backend = "memory"

    def __init__(self):
        self.conversations: Dict[str, list] = {}
        self.response_cache: Dict[str, CacheEntry] = {}
        self.user_response_keys: Dict[str, set] = {}

    def add_conversation_turn(self, user_id: str, role: str, content: str):
        if user_id not in self.conversations:
            self.conversations[user_id] = []

        self.conversations[user_id].append(
            {
                "role": role,
                "content": content,
                "timestamp": datetime.now().isoformat(),
            }
        )

    def get_conversation_history(self, user_id: str) -> list:
        return self.conversations.get(user_id, [])

    def clear_conversation(self, user_id: str):
        if user_id in self.conversations:
            del self.conversations[user_id]

    def get_cached_response(self, query: str, user_id: str) -> Optional[Dict]:
        query_hash = self._hash_query(query, user_id)

        if query_hash in self.response_cache:
            entry = self.response_cache[query_hash]
            if not entry.is_expired():
                return entry.access()
            del self.response_cache[query_hash]

        return None

    def cache_response(
        self,
        query: str,
        user_id: str,
        response: Dict,
        ttl_seconds: int = CACHE_TTL_SECONDS,
    ):
        query_hash = self._hash_query(query, user_id)
        self.response_cache[query_hash] = CacheEntry(response, ttl_seconds)
        self.user_response_keys.setdefault(user_id, set()).add(query_hash)

    def invalidate_user_response_cache(self, user_id: str):
        keys = self.user_response_keys.pop(user_id, set())
        removed = 0
        for key in keys:
            if key in self.response_cache:
                del self.response_cache[key]
                removed += 1
        return removed

    def get_cache_stats(self) -> Dict:
        total_entries = len(self.response_cache)
        active_entries = sum(
            1 for entry in self.response_cache.values() if not entry.is_expired()
        )
        total_accesses = sum(entry.access_count for entry in self.response_cache.values())

        return {
            "backend": self.backend,
            "redis_enabled": False,
            "total_entries": total_entries,
            "active_entries": active_entries,
            "expired_entries": total_entries - active_entries,
            "total_accesses": total_accesses,
            "conversations": len(self.conversations),
        }

    def clear_expired(self):
        expired_keys = [
            key
            for key, entry in self.response_cache.items()
            if entry.is_expired()
        ]
        for key in expired_keys:
            del self.response_cache[key]
        return len(expired_keys)

    def _hash_query(self, query: str, user_id: str) -> str:
        combined = f"{user_id}:{query.lower().strip()}"
        return hashlib.md5(combined.encode()).hexdigest()


class RedisConversationCache:
    """Redis-backed cache for conversation history and chat responses."""

    backend = "redis"
    RESPONSE_PREFIX = "chat:response"
    CONVERSATION_PREFIX = "chat:conversation"
    RESPONSE_KEY_SET = "chat:meta:response_keys"
    CONVERSATION_USER_SET = "chat:meta:conversation_users"
    ACCESS_COUNTER = "chat:meta:response_access_total"
    USER_RESPONSE_SET_PREFIX = "chat:meta:user_response_keys"

    def __init__(self, redis_url: str, default_ttl_seconds: int = CACHE_TTL_SECONDS):
        if redis is None:
            raise RuntimeError("redis package is not installed")

        self.default_ttl_seconds = default_ttl_seconds
        self.client = redis.from_url(redis_url, decode_responses=True)
        self.client.ping()

    def add_conversation_turn(self, user_id: str, role: str, content: str):
        key = self._conversation_key(user_id)
        payload = json.dumps(
            {
                "role": role,
                "content": content,
                "timestamp": datetime.now().isoformat(),
            }
        )
        self.client.rpush(key, payload)
        self.client.expire(key, self.default_ttl_seconds)
        self.client.sadd(self.CONVERSATION_USER_SET, user_id)

    def get_conversation_history(self, user_id: str) -> list:
        key = self._conversation_key(user_id)
        items = self.client.lrange(key, 0, -1)
        return [json.loads(item) for item in items]

    def clear_conversation(self, user_id: str):
        self.client.delete(self._conversation_key(user_id))
        self.client.srem(self.CONVERSATION_USER_SET, user_id)

    def get_cached_response(self, query: str, user_id: str) -> Optional[Dict]:
        key = self._response_key(query, user_id)
        payload = self.client.get(key)
        if not payload:
            return None

        self.client.incr(self.ACCESS_COUNTER)
        self.client.expire(key, self.default_ttl_seconds)
        return json.loads(payload)

    def cache_response(
        self,
        query: str,
        user_id: str,
        response: Dict,
        ttl_seconds: int = CACHE_TTL_SECONDS,
    ):
        key = self._response_key(query, user_id)
        self.client.setex(key, ttl_seconds, json.dumps(response))
        self.client.sadd(self.RESPONSE_KEY_SET, key)
        self.client.sadd(self._user_response_set_key(user_id), key)

    def invalidate_user_response_cache(self, user_id: str):
        removed = 0
        set_key = self._user_response_set_key(user_id)
        for key in self.client.smembers(set_key):
            if self.client.delete(key):
                removed += 1
            self.client.srem(self.RESPONSE_KEY_SET, key)
        self.client.delete(set_key)
        return removed

    def get_cache_stats(self) -> Dict:
        total_entries = 0
        active_entries = 0

        for key in self.client.smembers(self.RESPONSE_KEY_SET):
            total_entries += 1
            if self.client.exists(key):
                active_entries += 1

        return {
            "backend": self.backend,
            "redis_enabled": True,
            "redis_url": REDIS_URL,
            "total_entries": total_entries,
            "active_entries": active_entries,
            "expired_entries": total_entries - active_entries,
            "total_accesses": int(self.client.get(self.ACCESS_COUNTER) or 0),
            "conversations": sum(
                1
                for user_id in self.client.smembers(self.CONVERSATION_USER_SET)
                if self.client.exists(self._conversation_key(user_id))
            ),
        }

    def clear_expired(self):
        removed = 0
        for key in self.client.smembers(self.RESPONSE_KEY_SET):
            if not self.client.exists(key):
                self.client.srem(self.RESPONSE_KEY_SET, key)
                removed += 1

        for user_id in self.client.smembers(self.CONVERSATION_USER_SET):
            if not self.client.exists(self._conversation_key(user_id)):
                self.client.srem(self.CONVERSATION_USER_SET, user_id)

        return removed

    def _response_key(self, query: str, user_id: str) -> str:
        return f"{self.RESPONSE_PREFIX}:{self._hash_query(query, user_id)}"

    def _conversation_key(self, user_id: str) -> str:
        return f"{self.CONVERSATION_PREFIX}:{user_id}"

    def _user_response_set_key(self, user_id: str) -> str:
        return f"{self.USER_RESPONSE_SET_PREFIX}:{user_id}"

    def _hash_query(self, query: str, user_id: str) -> str:
        combined = f"{user_id}:{query.lower().strip()}"
        return hashlib.md5(combined.encode()).hexdigest()


_conversation_cache = None


def _build_cache():
    if REDIS_ENABLED:
        try:
            return RedisConversationCache(REDIS_URL, CACHE_TTL_SECONDS)
        except Exception as exc:
            print(f"Redis cache unavailable, falling back to memory cache: {exc}")

    return InMemoryConversationCache()


def get_conversation_cache():
    global _conversation_cache
    if _conversation_cache is None:
        _conversation_cache = _build_cache()
    return _conversation_cache
