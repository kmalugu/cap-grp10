from __future__ import annotations

import json
import operator
import re
from typing import Annotated, Any, Dict, List, Optional, TypedDict

from backend.services.llm import get_llm
from backend.services.memory import StudentEntityMemory, get_memory_manager

SUPPORTED_AGENTS = [
    "memory",
    "fees",
    "calendar",
    "timetable",
    "course",
    "faculty",
    "map",
    "rag",
    "general",
]


class MultiAgentState(TypedDict):
    user_id: str
    conversation_id: str
    message: str
    entity_memory: Optional[StudentEntityMemory]
    relevant_vector_memories: List[Dict[str, Any]]
    recent_conversation_context: str
    rag_enabled: bool
    summary_context: str
    routes: List[str]
    current_route_index: int
    agent_results: Annotated[List[Dict[str, Any]], operator.add]
    response: str
    source: str
    is_from_docs: bool
    agents_used: List[str]


def extract_json_segment(text: str) -> str:
    text = text.strip()

    if "```json" in text:
        return text.split("```json", 1)[1].split("```", 1)[0].strip()
    if "```" in text:
        return text.split("```", 1)[1].split("```", 1)[0].strip()

    for opening, closing in (("[", "]"), ("{", "}")):
        start = text.find(opening)
        end = text.rfind(closing)
        if start != -1 and end != -1 and end > start:
            return text[start : end + 1].strip()

    return text


def load_json_response(text: str, default: Any) -> Any:
    try:
        return json.loads(extract_json_segment(text))
    except Exception:
        return default


def format_json(data: Any) -> str:
    return json.dumps(data, indent=2, ensure_ascii=True)


def build_summary_memory_context(user_id: str, limit: int = 3) -> str:
    memory_manager = get_memory_manager()
    summaries = memory_manager.get_all_summaries(user_id)

    if not summaries:
        return "No prior summary memory available."

    summaries = sorted(
        summaries,
        key=lambda summary: summary.last_updated or summary.timestamp,
        reverse=True,
    )[:limit]

    lines = []
    for summary in summaries:
        topics = ", ".join(summary.key_topics) if summary.key_topics else "General"
        lines.append(
            f"- Conversation {summary.conversation_id}: {summary.summary} "
            f"(topics: {topics})"
        )
    return "\n".join(lines)


def build_entity_context(entity_memory: Optional[StudentEntityMemory]) -> str:
    if not entity_memory:
        return "No entity memory available."

    return (
        f"Name: {entity_memory.name or 'Unknown'}\n"
        f"Program: {entity_memory.program or 'Unknown'}\n"
        f"Year: {entity_memory.year or 'Unknown'}\n"
        f"Department: {entity_memory.department or 'Unknown'}\n"
        f"Current Issues: {', '.join(entity_memory.ongoing_issues) if entity_memory.ongoing_issues else 'None'}\n"
        f"Interested Courses: {', '.join(entity_memory.courses_interested) if entity_memory.courses_interested else 'None'}"
    )


def build_vector_context(relevant_vector_memories: List[Dict[str, Any]]) -> str:
    if not relevant_vector_memories:
        return "No relevant vector memory found."

    lines = []
    for memory in relevant_vector_memories[:3]:
        mem_type = memory.get("metadata", {}).get("type", "unknown")
        lines.append(f"- [{mem_type}] {memory.get('content', '')}")
    return "\n".join(lines)


def build_reference_context(
    entity_memory: Optional[StudentEntityMemory],
    summary_context: str,
    recent_conversation_context: str,
    relevant_vector_memories: List[Dict[str, Any]],
) -> str:
    return f"""Entity Memory:
{build_entity_context(entity_memory)}

Summary Memory:
{summary_context}

Relevant Vector Memory:
{build_vector_context(relevant_vector_memories)}

Recent Conversation Context:
{recent_conversation_context or 'No recent conversation context available.'}
"""


def dedupe_routes(routes: List[str]) -> List[str]:
    seen = set()
    unique_routes = []
    for route in routes:
        normalized = route.strip().lower()
        if normalized in SUPPORTED_AGENTS and normalized not in seen:
            seen.add(normalized)
            unique_routes.append(normalized)
    return unique_routes


def extract_course_code(message: str) -> Optional[str]:
    match = re.search(r"\b([A-Za-z]{2,}\d{2,})\b", message)
    if match:
        return match.group(1).upper()
    return None


def normalize_year(value: Any) -> Optional[int]:
    if value is None:
        return None

    if isinstance(value, int):
        return value

    text = str(value).strip().lower()
    mapping = {
        "1st": 1,
        "first": 1,
        "1": 1,
        "2nd": 2,
        "second": 2,
        "2": 2,
        "3rd": 3,
        "third": 3,
        "3": 3,
        "4th": 4,
        "fourth": 4,
        "4": 4,
        "final": 4,
        "final year": 4,
    }
    return mapping.get(text)


def extract_structured_args(
    agent_name: str,
    query: str,
    entity_memory: Optional[StudentEntityMemory],
    recent_conversation_context: str,
    relevant_vector_memories: Optional[List[Dict[str, Any]]],
    summary_context: str,
    schema: Dict[str, Any],
    instructions: str,
) -> Dict[str, Any]:
    llm = get_llm()
    prompt = f"""You extract arguments for the `{agent_name}` agent.

Query:
{query}

Reference context:
{build_reference_context(
    entity_memory,
    summary_context,
    recent_conversation_context,
    relevant_vector_memories or [],
)}

Instructions:
{instructions}

Return ONLY valid JSON matching this schema exactly:
{format_json(schema)}
"""
    return load_json_response(llm.invoke(prompt), dict(schema))
