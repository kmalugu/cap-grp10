from __future__ import annotations

from typing import Any, Dict, List, Optional

from backend.services.llm import get_llm
from backend.services.memory import StudentEntityMemory
from backend.tools.course_tool import get_course

from backend.services.agents.shared import (
    build_reference_context,
    extract_course_code,
    extract_structured_args,
    format_json,
)


def course_agent(
    message: str,
    entity_memory: Optional[StudentEntityMemory],
    recent_conversation_context: str,
    relevant_vector_memories: List[Dict[str, Any]],
    summary_context: str,
) -> Dict[str, Any]:
    detected_code = extract_course_code(message)
    args = extract_structured_args(
        "course",
        message,
        entity_memory,
        recent_conversation_context,
        relevant_vector_memories,
        summary_context,
        {"course_code": detected_code},
        "Find the course code in the query if present. Return the exact course code, like AI101. "
        "If no course code is present, use recent conversation context when it clearly refers to a previously discussed course. "
        "Otherwise leave it null.",
    )
    course_code = args.get("course_code") or detected_code

    if not course_code:
        return {
            "agent": "course",
            "response": "I can look up a course if you give me the course code, for example AI101.",
            "is_from_docs": False,
        }

    data = get_course(course_code)
    if isinstance(data, dict) and data.get("message"):
        return {
            "agent": "course",
            "response": f"I couldn't find details for course {course_code}.",
            "is_from_docs": False,
        }

    llm = get_llm()
    prompt = f"""You are the course agent.

User question:
{message}

Reference context:
{build_reference_context(entity_memory, summary_context, recent_conversation_context, relevant_vector_memories)}

Course data:
{format_json(data)}

Answer directly from the course data above.
"""
    return {
        "agent": "course",
        "response": llm.invoke(prompt),
        "is_from_docs": False,
    }
