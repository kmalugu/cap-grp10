from __future__ import annotations

from typing import Any, Dict, List, Optional

from backend.services.llm import get_llm
from backend.services.memory import StudentEntityMemory

from backend.services.agents.shared import build_reference_context


def general_agent(
    message: str,
    entity_memory: Optional[StudentEntityMemory],
    summary_context: str,
    recent_conversation_context: str,
    relevant_vector_memories: List[Dict[str, Any]],
) -> Dict[str, Any]:
    llm = get_llm()
    prompt = f"""You are the general assistant agent for a university chatbot.

Question:
{message}

Reference context:
{build_reference_context(entity_memory, summary_context, recent_conversation_context, relevant_vector_memories)}

Answer helpfully. If the user asks for official rules or policies and they are not in the
reference context, answer generally without pretending it came from official documentation.
"""
    return {
        "agent": "general",
        "response": llm.invoke(prompt),
        "is_from_docs": False,
    }
