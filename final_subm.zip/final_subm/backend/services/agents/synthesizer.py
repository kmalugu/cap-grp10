from __future__ import annotations

from typing import Any, Dict, List

from backend.services.llm import get_llm


def synthesize_agent(
    message: str,
    summary_context: str,
    results: List[Dict[str, Any]],
) -> str:
    llm = get_llm()
    formatted_results = "\n\n".join(
        f"Agent: {result['agent']}\nAnswer: {result['response']}" for result in results
    )
    prompt = f"""You are the final synthesizer for a university assistant.

User question:
{message}

Summary memory for reference:
{summary_context}

Specialist outputs:
{formatted_results}

Write one final response for the user. Merge overlapping points cleanly and keep the answer
natural, as if it came from one chat assistant.
"""
    return llm.invoke(prompt)
