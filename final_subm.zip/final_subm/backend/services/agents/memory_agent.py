from __future__ import annotations

from typing import Any, Dict, List, Optional

from backend.services.llm import get_llm
from backend.services.memory import StudentEntityMemory

from backend.services.agents.shared import build_reference_context


def memory_agent(
    message: str,
    entity_memory: Optional[StudentEntityMemory],
    summary_context: str,
    recent_conversation_context: str,
    relevant_vector_memories: List[Dict[str, Any]],
) -> Dict[str, Any]:
    llm = get_llm()
    prompt = f"""You are the memory agent for a university assistant.

Use ONLY the memory/reference context below to answer. If the requested detail is missing,
say clearly that it is not available in memory yet.

Question:
{message}

Reference context:
{build_reference_context(entity_memory, summary_context, recent_conversation_context, relevant_vector_memories)}
"""
    return {
        "agent": "memory",
        "response": llm.invoke(prompt),
        "is_from_docs": False,
    }
