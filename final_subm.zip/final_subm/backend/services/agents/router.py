from __future__ import annotations

import re
from typing import List, Optional

from backend.services.llm import get_llm
from backend.services.memory import StudentEntityMemory

from backend.services.agents.shared import (
    SUPPORTED_AGENTS,
    build_entity_context,
    dedupe_routes,
    extract_course_code,
    load_json_response,
)


def router_agent(
    message: str,
    summary_context: str,
    entity_memory: Optional[StudentEntityMemory],
    recent_conversation_context: str,
    rag_enabled: bool,
) -> List[str]:
    normalized = message.strip().lower()
    routes: List[str] = []

    if re.search(
        r"\b(what('?s| is)? my name|who am i|what('?s| is)? my program|what('?s| is)? my department|what year am i in)\b",
        normalized,
    ):
        return ["memory"]

    keyword_patterns = {
        "fees": r"\b(fee|fees|tuition|scholarship|cost|payment)\b",
        "calendar": r"\b(calendar|deadline|semester start|exam date|holiday|important date)\b",
        "timetable": r"\b(timetable|schedule|class timing|class schedule|routine)\b",
        "course": r"\b(course|subject|syllabus|credits|prerequisite)\b",
        "faculty": r"\b(faculty|professor|teacher|lecturer|staff)\b",
        "map": r"\b(where is|location|map|building|campus map)\b",
    }

    for route_name, pattern in keyword_patterns.items():
        if re.search(pattern, normalized):
            routes.append(route_name)

    if extract_course_code(message) and "course" not in routes:
        routes.append("course")

    if routes:
        if rag_enabled and re.search(
            r"\b(rule|policy|guideline|admission|hostel|library|lab|placement|conduct)\b",
            normalized,
        ):
            routes.append("rag")
        return dedupe_routes(routes)

    if not rag_enabled:
        return ["general"]

    llm = get_llm()
    prompt = f"""You are a router agent for a university assistant.

Choose one or more routes from:
{", ".join(SUPPORTED_AGENTS)}

User query:
{message}

Recent conversation context:
{recent_conversation_context or 'No recent conversation context available.'}

Summary memory for reference:
{summary_context}

Entity memory for reference:
{build_entity_context(entity_memory)}

Rules:
- Use `memory` for questions about the student's own stored profile.
- Use `fees`, `calendar`, `timetable`, `course`, `faculty`, or `map` for structured-data questions.
- Use `rag` for handbook, rules, policies, facilities, admissions, hostel, placement, library, or lab queries.
- Use recent conversation context to resolve follow-up questions that omit the topic, program, department, course, or location.
- Use `general` for greetings, conversation, or fallback.
- Return a JSON array only.
"""
    routed = load_json_response(llm.invoke(prompt), ["general"])
    if not isinstance(routed, list):
        return ["general"]

    routes = dedupe_routes([str(item) for item in routed])
    return routes or ["general"]
