from __future__ import annotations

from typing import Any, Dict, List, Optional

from backend.services.llm import get_llm
from backend.services.memory import StudentEntityMemory
from backend.services.retriever import retrieve_documents

from backend.services.agents.shared import build_reference_context


def rag_agent(
    message: str,
    entity_memory: Optional[StudentEntityMemory],
    summary_context: str,
    recent_conversation_context: str,
    relevant_vector_memories: List[Dict[str, Any]],
    rag_enabled: bool,
) -> Dict[str, Any]:
    if not rag_enabled:
        return {
            "agent": "rag",
            "response": "Documentation lookup is currently disabled.",
            "is_from_docs": False,
        }

    documents = retrieve_documents(message, k=5)
    if not documents:
        return {
            "agent": "rag",
            "response": "I couldn't find relevant documentation for that question.",
            "is_from_docs": False,
        }

    doc_context = "\n\n".join(doc.page_content[:500] for doc in documents)
    llm = get_llm()
    prompt = f"""You are the documentation agent for a university assistant.

Answer ONLY from the documentation context below. You may use summary memory only as background
reference for the student's context, not as the source of factual policy information.

Question:
{message}

Reference context:
{build_reference_context(entity_memory, summary_context, recent_conversation_context, relevant_vector_memories)}

Documentation context:
{doc_context}
"""
    return {
        "agent": "rag",
        "response": llm.invoke(prompt),
        "is_from_docs": True,
    }
