from __future__ import annotations

from typing import Any, Dict, List, Optional

from backend.services.llm import get_llm
from backend.services.memory import StudentEntityMemory
from backend.tools.map_tool import get_location

from backend.services.agents.shared import (
    build_reference_context,
    extract_structured_args,
    format_json,
)


def map_agent(
    message: str,
    entity_memory: Optional[StudentEntityMemory],
    recent_conversation_context: str,
    relevant_vector_memories: List[Dict[str, Any]],
    summary_context: str,
) -> Dict[str, Any]:
    args = extract_structured_args(
        "map",
        message,
        entity_memory,
        recent_conversation_context,
        relevant_vector_memories,
        summary_context,
        {"place_name": None},
        "Infer the campus place/building name from the query. Use recent conversation context when the user refers to a previously mentioned place. Return only the place name.",
    )
    place_name = args.get("place_name")

    if not place_name:
        return {
            "agent": "map",
            "response": "I can help with campus locations if you tell me the place name.",
            "is_from_docs": False,
        }

    data = get_location(place_name)
    if isinstance(data, dict) and data.get("message"):
        return {
            "agent": "map",
            "response": f"I couldn't find a campus location called {place_name}.",
            "is_from_docs": False,
        }

    llm = get_llm()
    prompt = f"""You are the campus map agent.

User question:
{message}

Reference context:
{build_reference_context(entity_memory, summary_context, recent_conversation_context, relevant_vector_memories)}

Location data:
{format_json(data)}

Answer directly and include the map link if present.
"""
    return {
        "agent": "map",
        "response": llm.invoke(prompt),
        "is_from_docs": False,
    }
