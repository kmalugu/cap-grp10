from __future__ import annotations

from typing import Any, Dict, List, Optional

from backend.services.llm import get_llm
from backend.services.memory import StudentEntityMemory
from backend.tools.calendar_tool import get_calendar

from backend.services.agents.shared import (
    build_reference_context,
    extract_structured_args,
    format_json,
)


def calendar_agent(
    message: str,
    entity_memory: Optional[StudentEntityMemory],
    recent_conversation_context: str,
    relevant_vector_memories: List[Dict[str, Any]],
    summary_context: str,
) -> Dict[str, Any]:
    args = extract_structured_args(
        "calendar",
        message,
        entity_memory,
        recent_conversation_context,
        relevant_vector_memories,
        summary_context,
        {"program": entity_memory.program if entity_memory else None},
        "Infer the academic program from the query. Use entity memory and recent conversation context if the user does not say it explicitly.",
    )
    program = args.get("program")

    if not program:
        return {
            "agent": "calendar",
            "response": "I can look up the academic calendar once you tell me the program, for example BTech or MBA.",
            "is_from_docs": False,
        }

    data = get_calendar(program)
    if isinstance(data, dict) and data.get("message"):
        return {
            "agent": "calendar",
            "response": f"I couldn't find academic calendar data for {program}.",
            "is_from_docs": False,
        }

    llm = get_llm()
    prompt = f"""You are the academic calendar agent.

User question:
{message}

Reference context:
{build_reference_context(entity_memory, summary_context, recent_conversation_context, relevant_vector_memories)}

Calendar data:
{format_json(data)}

Answer the question directly using the calendar data above.
"""
    return {
        "agent": "calendar",
        "response": llm.invoke(prompt),
        "is_from_docs": False,
    }
