from typing import Any, Dict, List, Optional

from langgraph.graph import END, StateGraph

from backend.services.memory import StudentEntityMemory

from backend.services.agents.calendar_agent import calendar_agent
from backend.services.agents.course_agent import course_agent
from backend.services.agents.faculty_agent import faculty_agent
from backend.services.agents.fees_agent import fees_agent
from backend.services.agents.general_agent import general_agent
from backend.services.agents.map_agent import map_agent
from backend.services.agents.memory_agent import memory_agent
from backend.services.agents.rag_agent import rag_agent
from backend.services.agents.router import router_agent
from backend.services.agents.shared import MultiAgentState, build_summary_memory_context
from backend.services.agents.synthesizer import synthesize_agent
from backend.services.agents.timetable_agent import timetable_agent


def run_agent_for_route(route: str, state: MultiAgentState) -> Dict[str, Any]:
    message = state["message"]
    entity_memory = state["entity_memory"]
    summary_context = state["summary_context"]
    recent_conversation_context = state["recent_conversation_context"]
    relevant_vector_memories = state["relevant_vector_memories"]
    rag_enabled = state["rag_enabled"]

    if route == "memory":
        return memory_agent(
            message,
            entity_memory,
            summary_context,
            recent_conversation_context,
            relevant_vector_memories,
        )
    if route == "fees":
        return fees_agent(
            message,
            entity_memory,
            recent_conversation_context,
            relevant_vector_memories,
            summary_context,
        )
    if route == "calendar":
        return calendar_agent(
            message,
            entity_memory,
            recent_conversation_context,
            relevant_vector_memories,
            summary_context,
        )
    if route == "timetable":
        return timetable_agent(
            message,
            entity_memory,
            recent_conversation_context,
            relevant_vector_memories,
            summary_context,
        )
    if route == "course":
        return course_agent(
            message,
            entity_memory,
            recent_conversation_context,
            relevant_vector_memories,
            summary_context,
        )
    if route == "faculty":
        return faculty_agent(
            message,
            entity_memory,
            recent_conversation_context,
            relevant_vector_memories,
            summary_context,
        )
    if route == "map":
        return map_agent(
            message,
            entity_memory,
            recent_conversation_context,
            relevant_vector_memories,
            summary_context,
        )
    if route == "rag":
        return rag_agent(
            message,
            entity_memory,
            summary_context,
            recent_conversation_context,
            relevant_vector_memories,
            rag_enabled,
        )
    return general_agent(
        message,
        entity_memory,
        summary_context,
        recent_conversation_context,
        relevant_vector_memories,
    )


def prepare_multi_agent_context(state: MultiAgentState) -> Dict[str, Any]:
    return {
        "summary_context": build_summary_memory_context(state["user_id"]),
        "current_route_index": 0,
    }


def route_multi_agent_query(state: MultiAgentState) -> Dict[str, Any]:
    routes = router_agent(
        state["message"],
        state["summary_context"],
        state["entity_memory"],
        state["recent_conversation_context"],
        state["rag_enabled"],
    )
    return {"routes": routes or ["general"]}


def run_next_multi_agent(state: MultiAgentState) -> Dict[str, Any]:
    routes = state.get("routes") or ["general"]
    current_route_index = state.get("current_route_index", 0)
    route = routes[current_route_index]
    result = run_agent_for_route(route, state)
    return {
        "agent_results": [result],
        "current_route_index": current_route_index + 1,
    }


def should_continue_multi_agent(state: MultiAgentState) -> str:
    routes = state.get("routes") or []
    if state.get("current_route_index", 0) < len(routes):
        return "run_agent"
    return "finalize"


def finalize_multi_agent_response(state: MultiAgentState) -> Dict[str, Any]:
    agent_results = state.get("agent_results") or []

    if not agent_results:
        fallback_result = general_agent(
            state["message"],
            state["entity_memory"],
            state["summary_context"],
            state["recent_conversation_context"],
            state["relevant_vector_memories"],
        )
        agent_results = [fallback_result]

    if len(agent_results) == 1:
        final_response = agent_results[0]["response"]
        source = agent_results[0]["agent"]
    else:
        final_response = synthesize_agent(
            state["message"],
            state["summary_context"],
            agent_results,
        )
        source = "multi_agent"

    return {
        "response": final_response,
        "source": source,
        "is_from_docs": any(result["is_from_docs"] for result in agent_results),
        "agents_used": [result["agent"] for result in agent_results],
    }


def create_multi_agent_graph():
    workflow = StateGraph(MultiAgentState)

    workflow.add_node("prepare_context", prepare_multi_agent_context)
    workflow.add_node("route_query", route_multi_agent_query)
    workflow.add_node("run_agent", run_next_multi_agent)
    workflow.add_node("finalize", finalize_multi_agent_response)

    workflow.set_entry_point("prepare_context")
    workflow.add_edge("prepare_context", "route_query")
    workflow.add_conditional_edges(
        "route_query",
        should_continue_multi_agent,
        {
            "run_agent": "run_agent",
            "finalize": "finalize",
        },
    )
    workflow.add_conditional_edges(
        "run_agent",
        should_continue_multi_agent,
        {
            "run_agent": "run_agent",
            "finalize": "finalize",
        },
    )
    workflow.add_edge("finalize", END)

    return workflow.compile()


multi_agent_graph = create_multi_agent_graph()


def generate_multi_agent_response(
    *,
    user_id: str,
    conversation_id: str,
    message: str,
    entity_memory: Optional[StudentEntityMemory],
    relevant_vector_memories: List[Dict[str, Any]],
    recent_conversation_context: str,
    rag_enabled: bool,
) -> Dict[str, Any]:
    initial_state: MultiAgentState = {
        "user_id": user_id,
        "conversation_id": conversation_id,
        "message": message,
        "entity_memory": entity_memory,
        "relevant_vector_memories": relevant_vector_memories,
        "recent_conversation_context": recent_conversation_context,
        "rag_enabled": rag_enabled,
        "summary_context": "",
        "routes": [],
        "current_route_index": 0,
        "agent_results": [],
        "response": "",
        "source": "",
        "is_from_docs": False,
        "agents_used": [],
    }

    final_state = multi_agent_graph.invoke(initial_state)

    return {
        "response": final_state["response"],
        "source": final_state["source"],
        "is_from_docs": final_state["is_from_docs"],
        "agents_used": final_state["agents_used"],
        "summary_context": final_state["summary_context"],
    }
