from __future__ import annotations

from typing import Any, Dict, List, Optional

from backend.services.llm import get_llm
from backend.services.memory import StudentEntityMemory
from backend.tools.faculty_tool import get_faculty

from backend.services.agents.shared import (
    build_reference_context,
    extract_structured_args,
    format_json,
)


def faculty_agent(
    message: str,
    entity_memory: Optional[StudentEntityMemory],
    recent_conversation_context: str,
    relevant_vector_memories: List[Dict[str, Any]],
    summary_context: str,
) -> Dict[str, Any]:
    args = extract_structured_args(
        "faculty",
        message,
        entity_memory,
        recent_conversation_context,
        relevant_vector_memories,
        summary_context,
        {"department": entity_memory.department if entity_memory else None},
        "Infer the department from the query. Use entity memory and recent conversation context if the user omits it.",
    )
    department = args.get("department")

    if not department:
        return {
            "agent": "faculty",
            "response": "I can look up faculty details once you tell me the department.",
            "is_from_docs": False,
        }

    data = get_faculty(department)
    if isinstance(data, dict) and data.get("message"):
        return {
            "agent": "faculty",
            "response": f"I couldn't find faculty details for {department}.",
            "is_from_docs": False,
        }

    llm = get_llm()
    prompt = f"""You are the faculty agent.

User question:
{message}

Reference context:
{build_reference_context(entity_memory, summary_context, recent_conversation_context, relevant_vector_memories)}

Faculty data:
{format_json(data)}

Answer directly and keep the result easy to scan.
"""
    return {
        "agent": "faculty",
        "response": llm.invoke(prompt),
        "is_from_docs": False,
    }
