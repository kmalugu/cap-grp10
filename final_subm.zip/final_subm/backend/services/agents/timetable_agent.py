from __future__ import annotations

from typing import Any, Dict, List, Optional

from backend.services.llm import get_llm
from backend.services.memory import StudentEntityMemory
from backend.tools.timetable_tool import get_timetable

from backend.services.agents.shared import (
    build_reference_context,
    extract_structured_args,
    format_json,
    normalize_year,
)


def timetable_agent(
    message: str,
    entity_memory: Optional[StudentEntityMemory],
    recent_conversation_context: str,
    relevant_vector_memories: List[Dict[str, Any]],
    summary_context: str,
) -> Dict[str, Any]:
    args = extract_structured_args(
        "timetable",
        message,
        entity_memory,
        recent_conversation_context,
        relevant_vector_memories,
        summary_context,
        {
            "year": entity_memory.year if entity_memory else None,
            "department": entity_memory.department if entity_memory else None,
        },
        "Infer `year` and `department` from the query. Use entity memory and recent conversation context when missing. "
        "Return year as 1, 2, 3, or 4 when possible.",
    )
    year = normalize_year(args.get("year"))
    department = args.get("department")

    if year is None or not department:
        return {
            "agent": "timetable",
            "response": "I can get the timetable once I know both the year and department, for example year 2 CSE.",
            "is_from_docs": False,
        }

    data = get_timetable(year, department)
    if isinstance(data, dict) and data.get("message"):
        return {
            "agent": "timetable",
            "response": f"I couldn't find a timetable for year {year} {department}.",
            "is_from_docs": False,
        }

    llm = get_llm()
    prompt = f"""You are the timetable agent.

User question:
{message}

Reference context:
{build_reference_context(entity_memory, summary_context, recent_conversation_context, relevant_vector_memories)}

Timetable data:
{format_json(data)}

Answer directly. Summarize the timetable clearly instead of dumping raw JSON.
"""
    return {
        "agent": "timetable",
        "response": llm.invoke(prompt),
        "is_from_docs": False,
    }
