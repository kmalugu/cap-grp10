from __future__ import annotations

from typing import Any, Dict, List, Optional

from backend.services.llm import get_llm
from backend.services.memory import StudentEntityMemory
from backend.tools.fees_tool import get_fees

from backend.services.agents.shared import (
    build_reference_context,
    extract_structured_args,
    format_json,
)


def fees_agent(
    message: str,
    entity_memory: Optional[StudentEntityMemory],
    recent_conversation_context: str,
    relevant_vector_memories: List[Dict[str, Any]],
    summary_context: str,
) -> Dict[str, Any]:
    args = extract_structured_args(
        "fees",
        message,
        entity_memory,
        recent_conversation_context,
        relevant_vector_memories,
        summary_context,
        {
            "program": entity_memory.program if entity_memory else None,
            "nationality": "domestic",
        },
        "Infer the target program and nationality from the query. "
        "Use entity memory and recent conversation context when the query omits them. "
        "Keep nationality as `domestic` unless the user clearly asks for international.",
    )
    program = args.get("program")
    nationality = args.get("nationality") or "domestic"

    if not program:
        return {
            "agent": "fees",
            "response": "I can help with fees and scholarships. Please mention the program name, for example BTech or MBA.",
            "is_from_docs": False,
        }

    data = get_fees(program, nationality)
    if isinstance(data, dict) and data.get("message"):
        return {
            "agent": "fees",
            "response": f"I couldn't find fee details for {program} ({nationality}).",
            "is_from_docs": False,
        }

    llm = get_llm()
    prompt = f"""You are the fees agent for a university assistant.

User question:
{message}

Reference context:
{build_reference_context(entity_memory, summary_context, recent_conversation_context, relevant_vector_memories)}

Fee data:
{format_json(data)}

Answer the user directly using the fee data above. Mention the program and nationality.
"""
    return {
        "agent": "fees",
        "response": llm.invoke(prompt),
        "is_from_docs": False,
    }
