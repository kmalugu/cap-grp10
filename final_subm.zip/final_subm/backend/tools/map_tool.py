# Map Tool Implementation
import json
import os

# Get the absolute path to the data file
base_path = os.path.join(os.path.dirname(__file__), "../..", "data", "structured", "campus_map.json")
with open(base_path) as f:
    data = json.load(f)

def get_location(place_name):
    """
    Fetch campus location details
    """
    for location in data["locations"]:
        if location["name"].lower() == place_name.lower():
            return {
                "name": location["name"],
                "description": location["description"],
                "map_link": f"https://www.google.com/maps/search/?api=1&query={location['coordinates']}"
            }

    return {"message": "Location not found"}