# Faculty Tool Implementation

import pandas as pd
import os

# Get the absolute path to the data file
base_path = os.path.join(os.path.dirname(__file__), "../..", "data", "structured", "faculty.csv")
df = pd.read_csv(base_path)

def get_faculty(department):
    """
    Fetch faculty details by department
    """
    result = df[df["department"].str.lower() == department.lower()]

    if result.empty:
        return {"message": "No faculty found"}

    return result.to_dict(orient="records")
