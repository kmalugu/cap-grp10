# Calendar Tool Implementation

import pandas as pd
import os

# Get the absolute path to the data file
base_path = os.path.join(os.path.dirname(__file__), "../..", "data", "structured", "academic_calendar.csv")
df = pd.read_csv(base_path)

def get_calendar(program):
    """
    Fetch academic calendar for a program
    """
    result = df[df["program"].str.lower() == program.lower()]

    if result.empty:
        return {"message": "No calendar data found"}

    return result.to_dict(orient="records")