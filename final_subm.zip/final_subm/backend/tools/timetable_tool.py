# Timetable Tool Implementation

import pandas as pd
import os

# Get the absolute path to the data file
base_path = os.path.join(os.path.dirname(__file__), "../..", "data", "structured", "timetable.csv")
df = pd.read_csv(base_path)

def get_timetable(year, department):
    """
    Fetch timetable based on year and department
    """
    result = df[
        (df["year"] == year) &
        (df["department"].str.lower() == department.lower())
    ]

    if result.empty:
        return {"message": "No timetable found"}

    return result.to_dict(orient="records")