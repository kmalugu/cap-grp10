# Fees Tool Implementation

import json
import os

# Get the absolute path to the data file
base_path = os.path.join(os.path.dirname(__file__), "../..", "data", "structured", "fees_scholarships.json")
with open(base_path) as f:
    data = json.load(f)

def get_fees(program, nationality="domestic"):
    """
    Fetch fee structure and scholarship info
    """
    # Make program lookup case-insensitive
    program_data = None
    for key, value in data.items():
        if key.lower() == program.lower():
            program_data = value
            break

    if not program_data:
        return {"message": "Program not found"}

    result = program_data.get(nationality.lower())

    if not result:
        return {"message": "Nationality data not found"}

    return result
