# Course Tool Implementation
import pandas as pd
import os

# Get the absolute path to the data file
base_path = os.path.join(os.path.dirname(__file__), "../..", "data", "structured", "course_catalog.csv")
df = pd.read_csv(base_path)

def get_course(course_code):
    """
    Fetch course details by course code
    """
    result = df[df["course_code"].str.lower() == course_code.lower()]

    if result.empty:
        return {"message": "Course not found"}

    return result.to_dict(orient="records")